var _s_d_l_8h =
[
    [ "SDL_INIT_AUDIO", "_s_d_l_8h.html#abeceb02c19508655cb05cc8e64206333", null ],
    [ "SDL_INIT_EVENTS", "_s_d_l_8h.html#addad89db9e13b46ebcd46a0db8ba0382", null ],
    [ "SDL_INIT_EVERYTHING", "_s_d_l_8h.html#a574afd93f30161d6e87449f675081fb5", null ],
    [ "SDL_INIT_GAMECONTROLLER", "_s_d_l_8h.html#ac224a9aa4208de0e9b03948ff9b5fe0a", null ],
    [ "SDL_INIT_HAPTIC", "_s_d_l_8h.html#adfd88189fec07574cae461b9dea75a85", null ],
    [ "SDL_INIT_JOYSTICK", "_s_d_l_8h.html#ad6b47d785eaa00d9c48e6c1cff4aef4b", null ],
    [ "SDL_INIT_NOPARACHUTE", "_s_d_l_8h.html#ab848174dfbc69cb2cc7bbf06a6e5c584", null ],
    [ "SDL_INIT_SENSOR", "_s_d_l_8h.html#a25711177b046dd1ccd2fcc2f123f117b", null ],
    [ "SDL_INIT_TIMER", "_s_d_l_8h.html#aadfaf3382d6e136b5944d1d5e7e50290", null ],
    [ "SDL_INIT_VIDEO", "_s_d_l_8h.html#afc988e510ed522628ffeb7c76f80c233", null ],
    [ "SDL_Init", "_s_d_l_8h.html#a8fc8d35348d7c74bad8392d776c937b8", null ],
    [ "SDL_InitSubSystem", "_s_d_l_8h.html#adfbfddc0ec609b5e5e5cb1c89298e4db", null ],
    [ "SDL_Quit", "_s_d_l_8h.html#afdabaf714781099083592051f2d9ac11", null ],
    [ "SDL_QuitSubSystem", "_s_d_l_8h.html#a14e9091982e09097985e10e3ca65debb", null ],
    [ "SDL_WasInit", "_s_d_l_8h.html#a04dc570990c697eed95681216801710d", null ]
];