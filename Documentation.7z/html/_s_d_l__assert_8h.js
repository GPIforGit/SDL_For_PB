var _s_d_l__assert_8h =
[
    [ "SDL_AssertData", "_s_d_l__assert_8h.html#struct_s_d_l___assert_data", [
      [ "always_ignore", "_s_d_l__assert_8h.html#a52448d9ce43ab0e2391bf0d77bd676ba", null ],
      [ "condition", "_s_d_l__assert_8h.html#a350b75a3ca7336e8c15fbe21494aeaae", null ],
      [ "filename", "_s_d_l__assert_8h.html#a7efa5e9c7494c7d4586359300221aa5d", null ],
      [ "function", "_s_d_l__assert_8h.html#afa24a6ca95b4977cec3238001927aa22", null ],
      [ "linenum", "_s_d_l__assert_8h.html#a696967e9c7408f4d9d8624ad6bd675f3", null ],
      [ "next", "_s_d_l__assert_8h.html#acbb7ff1c6f9666cdb6dbd637662f153b", null ],
      [ "trigger_count", "_s_d_l__assert_8h.html#afc560a7b9d6b86f43e495b81f9e68a86", null ]
    ] ],
    [ "SDL_assert", "_s_d_l__assert_8h.html#af03d71e27f06835f6a09358943c33b1d", null ],
    [ "SDL_assert_always", "_s_d_l__assert_8h.html#a22dedc823eb26ea054cbc584b614718e", null ],
    [ "SDL_assert_data", "_s_d_l__assert_8h.html#a74c575b310128e12358caf79aec09da7", null ],
    [ "SDL_ASSERT_LEVEL", "_s_d_l__assert_8h.html#afbd8fdb86f3bba968efccbd932877731", null ],
    [ "SDL_assert_paranoid", "_s_d_l__assert_8h.html#a4cc20db7eed29c5cd0e83f4f3d10860a", null ],
    [ "SDL_assert_release", "_s_d_l__assert_8h.html#a3af3f7dba7e28942c17e16745028a7da", null ],
    [ "SDL_assert_state", "_s_d_l__assert_8h.html#a15ee0b48c2893f92f851d251424837b6", null ],
    [ "SDL_disabled_assert", "_s_d_l__assert_8h.html#aeee78c1e2347a3cfe4ee3c215d497acd", null ],
    [ "SDL_enabled_assert", "_s_d_l__assert_8h.html#a560c9df30e5f2db3d81daef3bbe81992", null ],
    [ "SDL_FILE", "_s_d_l__assert_8h.html#a195c2795832718d008000d969eed96c3", null ],
    [ "SDL_FUNCTION", "_s_d_l__assert_8h.html#a30da3daba50f032ecda2c701e97da79d", null ],
    [ "SDL_LINE", "_s_d_l__assert_8h.html#a421a39f96c53fe309aa6d66b5c5bec22", null ],
    [ "SDL_NULL_WHILE_LOOP_CONDITION", "_s_d_l__assert_8h.html#a2ffca06819acf027ec29d6fd14c94cbe", null ],
    [ "SDL_TriggerBreakpoint", "_s_d_l__assert_8h.html#a42e8a6e0677acca7c1a927238b8dfe32", null ],
    [ "SDL_AssertionHandler", "_s_d_l__assert_8h.html#aa63dc5ca0d954add6893512583b08071", null ],
    [ "SDL_AssertState", "_s_d_l__assert_8h.html#a06d6a46a43cc7b34764c37398573ef1a", [
      [ "SDL_ASSERTION_RETRY", "_s_d_l__assert_8h.html#a06d6a46a43cc7b34764c37398573ef1aa0ccce3254f1d981283e0792cd70437df", null ],
      [ "SDL_ASSERTION_BREAK", "_s_d_l__assert_8h.html#a06d6a46a43cc7b34764c37398573ef1aace6f6a41a6b303e220828fbe25b5d2a6", null ],
      [ "SDL_ASSERTION_ABORT", "_s_d_l__assert_8h.html#a06d6a46a43cc7b34764c37398573ef1aa4cf9444bddf799c7638bbcc9c542799c", null ],
      [ "SDL_ASSERTION_IGNORE", "_s_d_l__assert_8h.html#a06d6a46a43cc7b34764c37398573ef1aa76eace7638278c093e24d78a91d6d772", null ],
      [ "SDL_ASSERTION_ALWAYS_IGNORE", "_s_d_l__assert_8h.html#a06d6a46a43cc7b34764c37398573ef1aaf8d1af4dc16f160217acadf2b8585fea", null ]
    ] ],
    [ "SDL_GetAssertionHandler", "_s_d_l__assert_8h.html#a61c95d5aa8a1bd701e829b0842e04f07", null ],
    [ "SDL_GetAssertionReport", "_s_d_l__assert_8h.html#aed3c2bfa62b62df905d6cd309a066e03", null ],
    [ "SDL_GetDefaultAssertionHandler", "_s_d_l__assert_8h.html#a34dc4d9332bcdc32b3a0baa3fc2966bc", null ],
    [ "SDL_ReportAssertion", "_s_d_l__assert_8h.html#a01ef51d076f7e9c3839fff4161a16550", null ],
    [ "SDL_ResetAssertionReport", "_s_d_l__assert_8h.html#abdbad45c4ede1953c784a7b312349a32", null ],
    [ "SDL_SetAssertionHandler", "_s_d_l__assert_8h.html#a12dc8edd25f52f3add69369b2978e689", null ]
];