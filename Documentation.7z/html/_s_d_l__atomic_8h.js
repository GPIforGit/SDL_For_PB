var _s_d_l__atomic_8h =
[
    [ "SDL_atomic_t", "_s_d_l__atomic_8h.html#struct_s_d_l__atomic__t", [
      [ "value", "_s_d_l__atomic_8h.html#ac4f474c82e82cbb89ca7c36dd52be0ed", null ]
    ] ],
    [ "SDL_AtomicDecRef", "_s_d_l__atomic_8h.html#a1602c33647cfdfa8ae49a2eef10341c9", null ],
    [ "SDL_AtomicIncRef", "_s_d_l__atomic_8h.html#a9c3b04a6ce4b6907bfb6e2ea4649ff64", null ],
    [ "SDL_CompilerBarrier", "_s_d_l__atomic_8h.html#a36d435d444dc115a5cc11fa7027576ec", null ],
    [ "SDL_MemoryBarrierAcquire", "_s_d_l__atomic_8h.html#aa33019d94c637a106218dde56b46a20a", null ],
    [ "SDL_MemoryBarrierRelease", "_s_d_l__atomic_8h.html#a041cb5705236fe51b35cb3d59c1fbba7", null ],
    [ "SDL_SpinLock", "_s_d_l__atomic_8h.html#a59179ff8d21c65b9d9a544f3c2088e81", null ],
    [ "SDL_AtomicAdd", "_s_d_l__atomic_8h.html#a36cadfcf8e2bda1974fbce6afdc6d529", null ],
    [ "SDL_AtomicCAS", "_s_d_l__atomic_8h.html#ad6b90be91abb896260930d3908c0437b", null ],
    [ "SDL_AtomicCASPtr", "_s_d_l__atomic_8h.html#aa3070cf7f391b522e08595822c2f0eba", null ],
    [ "SDL_AtomicGet", "_s_d_l__atomic_8h.html#a633c2661709f59c98f128f99aea36d96", null ],
    [ "SDL_AtomicGetPtr", "_s_d_l__atomic_8h.html#a46e899ee0013f3fae67eedaa6bce8947", null ],
    [ "SDL_AtomicLock", "_s_d_l__atomic_8h.html#a95ecd72190ba8e5ed6ed78d5d1b36509", null ],
    [ "SDL_AtomicSet", "_s_d_l__atomic_8h.html#a95b659308ebb16226d5c0cbf2188e51d", null ],
    [ "SDL_AtomicSetPtr", "_s_d_l__atomic_8h.html#a8cd69c02c71a64c2e509dc11a560d075", null ],
    [ "SDL_AtomicTryLock", "_s_d_l__atomic_8h.html#a5410c5f832f0d862282cd65fc432fc0b", null ],
    [ "SDL_AtomicUnlock", "_s_d_l__atomic_8h.html#a3fb14c56b17347349ac2fb5300205bac", null ],
    [ "SDL_MemoryBarrierAcquireFunction", "_s_d_l__atomic_8h.html#ae911d7eb425a9e83fd34ab1303412cba", null ],
    [ "SDL_MemoryBarrierReleaseFunction", "_s_d_l__atomic_8h.html#a4bec96c1fc632536952c309513a0258e", null ]
];