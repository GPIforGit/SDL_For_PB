var _s_d_l__audio_8h_struct_s_d_l___audio_spec =
[
    [ "callback", "_s_d_l__audio_8h.html#ab354de581da426745dcf6bcbc9ae03c2", null ],
    [ "channels", "_s_d_l__audio_8h.html#a2a6435e054f3ee99cbef44344bf83289", null ],
    [ "format", "_s_d_l__audio_8h.html#ab7e71a641a48b8199ef79f8c7f41af61", null ],
    [ "freq", "_s_d_l__audio_8h.html#ae0d22272b68e75d19ac0b80c01f806b6", null ],
    [ "padding", "_s_d_l__audio_8h.html#a489489d55916facdcdfcc2f20fe18309", null ],
    [ "samples", "_s_d_l__audio_8h.html#afe09cc5fd2bca18a01641bc94ff31b2c", null ],
    [ "silence", "_s_d_l__audio_8h.html#a9f3aae8ba0a529c3652087cb49ce6d11", null ],
    [ "size", "_s_d_l__audio_8h.html#a1338cce8a57eea552ed3ed77e28af0c0", null ],
    [ "userdata", "_s_d_l__audio_8h.html#afd0ffb02780e738d4c0a10ab833b7834", null ]
];