var _s_d_l__clipboard_8h =
[
    [ "SDL_GetClipboardText", "_s_d_l__clipboard_8h.html#abbe260fcf16ab844d6626e0bd83587d1", null ],
    [ "SDL_HasClipboardText", "_s_d_l__clipboard_8h.html#a415fa85de093cf6117626a9415394509", null ],
    [ "SDL_SetClipboardText", "_s_d_l__clipboard_8h.html#a36d97ed867cc1a6a4f015aaa5972ed46", null ]
];