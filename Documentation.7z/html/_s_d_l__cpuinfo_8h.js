var _s_d_l__cpuinfo_8h =
[
    [ "SDL_CACHELINE_SIZE", "_s_d_l__cpuinfo_8h.html#a05d74b2aab28d821ea7f3f78372fd00e", null ],
    [ "SDL_GetCPUCacheLineSize", "_s_d_l__cpuinfo_8h.html#aa699924d6c33d2cac8f1983c4ae4091c", null ],
    [ "SDL_GetCPUCount", "_s_d_l__cpuinfo_8h.html#a888cf77e53a67803402e1740a9639bd7", null ],
    [ "SDL_GetSystemRAM", "_s_d_l__cpuinfo_8h.html#af672834675f296bed0e226113695bebd", null ],
    [ "SDL_Has3DNow", "_s_d_l__cpuinfo_8h.html#a57efd279a93553cf43a54e3a49db6305", null ],
    [ "SDL_HasAltiVec", "_s_d_l__cpuinfo_8h.html#a9bc2024dc37b1d318eb197c161f8e50b", null ],
    [ "SDL_HasARMSIMD", "_s_d_l__cpuinfo_8h.html#aa5356bc82108c60c3bee504ee63fda7e", null ],
    [ "SDL_HasAVX", "_s_d_l__cpuinfo_8h.html#aec739a6c622987314d9a22899c4ba673", null ],
    [ "SDL_HasAVX2", "_s_d_l__cpuinfo_8h.html#a1fa7d982a27fb5a29fc1b291fc1054f4", null ],
    [ "SDL_HasAVX512F", "_s_d_l__cpuinfo_8h.html#a5108ee8d59a6d8a0a978f96b799bd3b1", null ],
    [ "SDL_HasMMX", "_s_d_l__cpuinfo_8h.html#aecec2f1434aa2eb5c82f974880f5181f", null ],
    [ "SDL_HasNEON", "_s_d_l__cpuinfo_8h.html#ac5096ea77af07eb4a9d4c754289b2a2b", null ],
    [ "SDL_HasRDTSC", "_s_d_l__cpuinfo_8h.html#afea666a39b6be7821303adcf16e83c47", null ],
    [ "SDL_HasSSE", "_s_d_l__cpuinfo_8h.html#aed4b71a601e3a12786a5280f59c0e26d", null ],
    [ "SDL_HasSSE2", "_s_d_l__cpuinfo_8h.html#aadc66ce3d29c669f6c78ee17c592336e", null ],
    [ "SDL_HasSSE3", "_s_d_l__cpuinfo_8h.html#ab0dfbc5d529ba0b65d1fff744da69f5e", null ],
    [ "SDL_HasSSE41", "_s_d_l__cpuinfo_8h.html#a6719853bee3dd03b8823540705a55932", null ],
    [ "SDL_HasSSE42", "_s_d_l__cpuinfo_8h.html#a9fea35e1593bb7981cdc1da4d0b2dccb", null ],
    [ "SDL_SIMDAlloc", "_s_d_l__cpuinfo_8h.html#a90747fee878a98aaba20e615f749308b", null ],
    [ "SDL_SIMDFree", "_s_d_l__cpuinfo_8h.html#a5bd4b538ff298ee8f2c31ed9da3253d4", null ],
    [ "SDL_SIMDGetAlignment", "_s_d_l__cpuinfo_8h.html#a99cf6527faa408c398a5a678aaf892d5", null ]
];