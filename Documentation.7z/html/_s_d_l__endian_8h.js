var _s_d_l__endian_8h =
[
    [ "SDL_BIG_ENDIAN", "_s_d_l__endian_8h.html#af22db189169b9aa7e356bf26b2a553f6", null ],
    [ "SDL_BYTEORDER", "_s_d_l__endian_8h.html#a0582882a281bd6c7580e454be3595703", null ],
    [ "SDL_LIL_ENDIAN", "_s_d_l__endian_8h.html#ad2b20e63545e73207b007b03bf08c2df", null ],
    [ "SDL_SwapBE16", "_s_d_l__endian_8h.html#aba916646d6a5abd082d5a21b406d3823", null ],
    [ "SDL_SwapBE32", "_s_d_l__endian_8h.html#a2a2c8f38728448268d6d881f4a699d54", null ],
    [ "SDL_SwapBE64", "_s_d_l__endian_8h.html#acc75cbc3e0bbf00dfd438e2186b91b03", null ],
    [ "SDL_SwapFloatBE", "_s_d_l__endian_8h.html#a12efebb66799de3703518e127361cfb7", null ],
    [ "SDL_SwapFloatLE", "_s_d_l__endian_8h.html#a2b64599423c3c710550238f2ee6fe3a8", null ],
    [ "SDL_SwapLE16", "_s_d_l__endian_8h.html#ae650119b14f608de5d79e0d73a444c35", null ],
    [ "SDL_SwapLE32", "_s_d_l__endian_8h.html#a14265c62e134bff318afba31ec1b0911", null ],
    [ "SDL_SwapLE64", "_s_d_l__endian_8h.html#ae1c6fb787318750e4e974345bd46ca4b", null ],
    [ "SDL_Swap16", "_s_d_l__endian_8h.html#a157cb22d3cc4b3f623822b15c3921e54", null ],
    [ "SDL_Swap32", "_s_d_l__endian_8h.html#a0f516a794e03b48778c9fcf41ddfe026", null ],
    [ "SDL_Swap64", "_s_d_l__endian_8h.html#a5ffaae586753b46ec5df4e601702324a", null ],
    [ "SDL_SwapFloat", "_s_d_l__endian_8h.html#a5f0f2d51e5ca5b27627ffc46ec892ce2", null ]
];