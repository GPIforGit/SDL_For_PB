var _s_d_l__error_8h =
[
    [ "SDL_InvalidParamError", "_s_d_l__error_8h.html#a5875c9c083a88408e11abeaa8391dfa5", null ],
    [ "SDL_OutOfMemory", "_s_d_l__error_8h.html#a440edcb93dba4e39c88ecf8dc676b6c1", null ],
    [ "SDL_Unsupported", "_s_d_l__error_8h.html#a45dc695e3a906dd40f00e204ace3bcf5", null ],
    [ "SDL_errorcode", "_s_d_l__error_8h.html#a5c417ba725f086b33390a5e5d5dabfe1", [
      [ "SDL_ENOMEM", "_s_d_l__error_8h.html#a5c417ba725f086b33390a5e5d5dabfe1aeaf35f3f31922623b3f773c749c7ae4a", null ],
      [ "SDL_EFREAD", "_s_d_l__error_8h.html#a5c417ba725f086b33390a5e5d5dabfe1abf97ce3dad635bff2cd5a97d095b1421", null ],
      [ "SDL_EFWRITE", "_s_d_l__error_8h.html#a5c417ba725f086b33390a5e5d5dabfe1a4ef09219815642370515451395f42683", null ],
      [ "SDL_EFSEEK", "_s_d_l__error_8h.html#a5c417ba725f086b33390a5e5d5dabfe1a3eda0d07dbe5bdcf0aeedf9e33866474", null ],
      [ "SDL_UNSUPPORTED", "_s_d_l__error_8h.html#a5c417ba725f086b33390a5e5d5dabfe1a8f8a44a4f0a0ec7f25ea8e3c88bcd54b", null ],
      [ "SDL_LASTERROR", "_s_d_l__error_8h.html#a5c417ba725f086b33390a5e5d5dabfe1a41573dd5f912c3648ac06b9dbb89cfcd", null ]
    ] ],
    [ "SDL_ClearError", "_s_d_l__error_8h.html#a007ed517953a99a46e46be567ef5609e", null ],
    [ "SDL_Error", "_s_d_l__error_8h.html#a0ec05915c315049ed2ab74cfe1ff980f", null ],
    [ "SDL_GetError", "_s_d_l__error_8h.html#ac88e1aa404a8f94aaee4ad6b94547647", null ],
    [ "SDL_SetError", "_s_d_l__error_8h.html#a26775853eaf43390bbceb27eb21a2240", null ]
];