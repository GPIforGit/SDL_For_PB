var _s_d_l__events_8h_struct_s_d_l___audio_device_event =
[
    [ "iscapture", "_s_d_l__events_8h.html#ab3a64d17b94fa7dc98dfb1e8b84cc00f", null ],
    [ "padding1", "_s_d_l__events_8h.html#a418ddf227b900bac743797ea1d27040f", null ],
    [ "padding2", "_s_d_l__events_8h.html#a09e3169fff93f108fc1dab93014eb1fb", null ],
    [ "padding3", "_s_d_l__events_8h.html#a2876881016c4222a885f1fabef292d1d", null ],
    [ "timestamp", "_s_d_l__events_8h.html#abf1ed7edeab81db9c05d899836a44a2f", null ],
    [ "type", "_s_d_l__events_8h.html#aa40a9b05c3154032b9f2d7220e9f08dc", null ],
    [ "which", "_s_d_l__events_8h.html#abd239700243abe3b42bfee05bbf65fa7", null ]
];