var _s_d_l__events_8h_struct_s_d_l___controller_button_event =
[
    [ "button", "_s_d_l__events_8h.html#a63c1d3c03e676c0ea5864dc6d0b0082c", null ],
    [ "padding1", "_s_d_l__events_8h.html#a418ddf227b900bac743797ea1d27040f", null ],
    [ "padding2", "_s_d_l__events_8h.html#a09e3169fff93f108fc1dab93014eb1fb", null ],
    [ "state", "_s_d_l__events_8h.html#a6b8d8e916bc56265a3fd279bd26b6d1b", null ],
    [ "timestamp", "_s_d_l__events_8h.html#abf1ed7edeab81db9c05d899836a44a2f", null ],
    [ "type", "_s_d_l__events_8h.html#aa40a9b05c3154032b9f2d7220e9f08dc", null ],
    [ "which", "_s_d_l__events_8h.html#a911f8b28e26cf5ad3e985e76d4987014", null ]
];