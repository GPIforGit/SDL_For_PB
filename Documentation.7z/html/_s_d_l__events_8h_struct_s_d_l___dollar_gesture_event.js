var _s_d_l__events_8h_struct_s_d_l___dollar_gesture_event =
[
    [ "error", "_s_d_l__events_8h.html#a7cfd13d282af770aaa971755fa092fca", null ],
    [ "gestureId", "_s_d_l__events_8h.html#ad3686651e65f306de48618ca5c121241", null ],
    [ "numFingers", "_s_d_l__events_8h.html#a55993ff0c72b4edca92780d6016b88af", null ],
    [ "timestamp", "_s_d_l__events_8h.html#abf1ed7edeab81db9c05d899836a44a2f", null ],
    [ "touchId", "_s_d_l__events_8h.html#a35f615f6a1333a7d89297b58ed1e9bbb", null ],
    [ "type", "_s_d_l__events_8h.html#aa40a9b05c3154032b9f2d7220e9f08dc", null ],
    [ "x", "_s_d_l__events_8h.html#ad0da36b2558901e21e7a30f6c227a45e", null ],
    [ "y", "_s_d_l__events_8h.html#aa4f0d3eebc3c443f9be81bf48561a217", null ]
];