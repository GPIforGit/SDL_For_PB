var _s_d_l__events_8h_struct_s_d_l___drop_event =
[
    [ "file", "_s_d_l__events_8h.html#adf16cd437526a5c5e0e0af87745acbb8", null ],
    [ "timestamp", "_s_d_l__events_8h.html#abf1ed7edeab81db9c05d899836a44a2f", null ],
    [ "type", "_s_d_l__events_8h.html#aa40a9b05c3154032b9f2d7220e9f08dc", null ],
    [ "windowID", "_s_d_l__events_8h.html#a78d9995068d6f40cd78bb8db7351b0a1", null ]
];