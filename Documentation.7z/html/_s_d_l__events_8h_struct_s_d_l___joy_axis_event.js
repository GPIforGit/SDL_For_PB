var _s_d_l__events_8h_struct_s_d_l___joy_axis_event =
[
    [ "axis", "_s_d_l__events_8h.html#a911494630318160a9e7ad91e3fe7e6a0", null ],
    [ "padding1", "_s_d_l__events_8h.html#a418ddf227b900bac743797ea1d27040f", null ],
    [ "padding2", "_s_d_l__events_8h.html#a09e3169fff93f108fc1dab93014eb1fb", null ],
    [ "padding3", "_s_d_l__events_8h.html#a2876881016c4222a885f1fabef292d1d", null ],
    [ "padding4", "_s_d_l__events_8h.html#a15b93152b4cd6e47ce3a9ab23f452c8a", null ],
    [ "timestamp", "_s_d_l__events_8h.html#abf1ed7edeab81db9c05d899836a44a2f", null ],
    [ "type", "_s_d_l__events_8h.html#aa40a9b05c3154032b9f2d7220e9f08dc", null ],
    [ "value", "_s_d_l__events_8h.html#ae36d960bffe70dcf148258f6dbcb0ef8", null ],
    [ "which", "_s_d_l__events_8h.html#a911f8b28e26cf5ad3e985e76d4987014", null ]
];