var _s_d_l__events_8h_struct_s_d_l___joy_hat_event =
[
    [ "hat", "_s_d_l__events_8h.html#a6ba9d2ca9d3fcb96dd9d63af1f70b785", null ],
    [ "padding1", "_s_d_l__events_8h.html#a418ddf227b900bac743797ea1d27040f", null ],
    [ "padding2", "_s_d_l__events_8h.html#a09e3169fff93f108fc1dab93014eb1fb", null ],
    [ "timestamp", "_s_d_l__events_8h.html#abf1ed7edeab81db9c05d899836a44a2f", null ],
    [ "type", "_s_d_l__events_8h.html#aa40a9b05c3154032b9f2d7220e9f08dc", null ],
    [ "value", "_s_d_l__events_8h.html#aa4f4dc93a5c52b0806c5844196244e51", null ],
    [ "which", "_s_d_l__events_8h.html#a911f8b28e26cf5ad3e985e76d4987014", null ]
];