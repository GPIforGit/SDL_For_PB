var _s_d_l__events_8h_struct_s_d_l___keyboard_event =
[
    [ "keysym", "_s_d_l__events_8h.html#a798f36b96d39e1dd994f72890632cf4f", null ],
    [ "padding2", "_s_d_l__events_8h.html#a09e3169fff93f108fc1dab93014eb1fb", null ],
    [ "padding3", "_s_d_l__events_8h.html#a2876881016c4222a885f1fabef292d1d", null ],
    [ "repeat", "_s_d_l__events_8h.html#a719e1ec1b2969d941426593f9822ef6d", null ],
    [ "state", "_s_d_l__events_8h.html#a6b8d8e916bc56265a3fd279bd26b6d1b", null ],
    [ "timestamp", "_s_d_l__events_8h.html#abf1ed7edeab81db9c05d899836a44a2f", null ],
    [ "type", "_s_d_l__events_8h.html#aa40a9b05c3154032b9f2d7220e9f08dc", null ],
    [ "windowID", "_s_d_l__events_8h.html#a78d9995068d6f40cd78bb8db7351b0a1", null ]
];