var _s_d_l__events_8h_struct_s_d_l___mouse_button_event =
[
    [ "button", "_s_d_l__events_8h.html#a63c1d3c03e676c0ea5864dc6d0b0082c", null ],
    [ "clicks", "_s_d_l__events_8h.html#a974b22c04825b730856e92942c3f5997", null ],
    [ "padding1", "_s_d_l__events_8h.html#a418ddf227b900bac743797ea1d27040f", null ],
    [ "state", "_s_d_l__events_8h.html#a6b8d8e916bc56265a3fd279bd26b6d1b", null ],
    [ "timestamp", "_s_d_l__events_8h.html#abf1ed7edeab81db9c05d899836a44a2f", null ],
    [ "type", "_s_d_l__events_8h.html#aa40a9b05c3154032b9f2d7220e9f08dc", null ],
    [ "which", "_s_d_l__events_8h.html#abd239700243abe3b42bfee05bbf65fa7", null ],
    [ "windowID", "_s_d_l__events_8h.html#a78d9995068d6f40cd78bb8db7351b0a1", null ],
    [ "x", "_s_d_l__events_8h.html#a133a64253d58ecff038d427c70b5b0aa", null ],
    [ "y", "_s_d_l__events_8h.html#ae6c55103b58b9a5b746ae4f6fbc9c901", null ]
];