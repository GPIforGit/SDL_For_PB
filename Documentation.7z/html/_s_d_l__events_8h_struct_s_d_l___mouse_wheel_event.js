var _s_d_l__events_8h_struct_s_d_l___mouse_wheel_event =
[
    [ "direction", "_s_d_l__events_8h.html#a342d821971b7a38ed4f40e9155a92eb2", null ],
    [ "timestamp", "_s_d_l__events_8h.html#abf1ed7edeab81db9c05d899836a44a2f", null ],
    [ "type", "_s_d_l__events_8h.html#aa40a9b05c3154032b9f2d7220e9f08dc", null ],
    [ "which", "_s_d_l__events_8h.html#abd239700243abe3b42bfee05bbf65fa7", null ],
    [ "windowID", "_s_d_l__events_8h.html#a78d9995068d6f40cd78bb8db7351b0a1", null ],
    [ "x", "_s_d_l__events_8h.html#a133a64253d58ecff038d427c70b5b0aa", null ],
    [ "y", "_s_d_l__events_8h.html#ae6c55103b58b9a5b746ae4f6fbc9c901", null ]
];