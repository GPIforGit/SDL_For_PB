var _s_d_l__events_8h_struct_s_d_l___text_editing_event =
[
    [ "length", "_s_d_l__events_8h.html#ae693591537f87d589b5a4fca7cbbf4dd", null ],
    [ "start", "_s_d_l__events_8h.html#adb4db5cb1d25adb3d1c10bf8f00bab48", null ],
    [ "text", "_s_d_l__events_8h.html#a43f22bc8cbe64d36f1e02c7f4ca9b445", null ],
    [ "timestamp", "_s_d_l__events_8h.html#abf1ed7edeab81db9c05d899836a44a2f", null ],
    [ "type", "_s_d_l__events_8h.html#aa40a9b05c3154032b9f2d7220e9f08dc", null ],
    [ "windowID", "_s_d_l__events_8h.html#a78d9995068d6f40cd78bb8db7351b0a1", null ]
];