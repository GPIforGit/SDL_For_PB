var _s_d_l__events_8h_struct_s_d_l___touch_finger_event =
[
    [ "dx", "_s_d_l__events_8h.html#a9eae6c1f38db98ab568f3ed3771a969d", null ],
    [ "dy", "_s_d_l__events_8h.html#a8f461b6142ce8725218813abb23b06a3", null ],
    [ "fingerId", "_s_d_l__events_8h.html#ac3c3601fcd3552c6bc353fadd95a0206", null ],
    [ "pressure", "_s_d_l__events_8h.html#ac870e1249bab4a2a68cc4126761d24ef", null ],
    [ "timestamp", "_s_d_l__events_8h.html#abf1ed7edeab81db9c05d899836a44a2f", null ],
    [ "touchId", "_s_d_l__events_8h.html#a35f615f6a1333a7d89297b58ed1e9bbb", null ],
    [ "type", "_s_d_l__events_8h.html#aa40a9b05c3154032b9f2d7220e9f08dc", null ],
    [ "windowID", "_s_d_l__events_8h.html#a78d9995068d6f40cd78bb8db7351b0a1", null ],
    [ "x", "_s_d_l__events_8h.html#ad0da36b2558901e21e7a30f6c227a45e", null ],
    [ "y", "_s_d_l__events_8h.html#aa4f0d3eebc3c443f9be81bf48561a217", null ]
];