var _s_d_l__filesystem_8h =
[
    [ "SDL_GetBasePath", "_s_d_l__filesystem_8h.html#a752d42a2e7fbff1292b7e54593be37bc", null ],
    [ "SDL_GetPrefPath", "_s_d_l__filesystem_8h.html#ab11eaf74d913eefb472475f0c8e312ce", null ]
];