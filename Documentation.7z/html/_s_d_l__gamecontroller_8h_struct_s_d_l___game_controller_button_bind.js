var _s_d_l__gamecontroller_8h_struct_s_d_l___game_controller_button_bind =
[
    [ "bindType", "_s_d_l__gamecontroller_8h.html#a3004ba500a61f95906163bf320a5a218", null ],
    [ "value", "_s_d_l__gamecontroller_8h.html#afe00c6d05eb3db5629a1a14d58af4b3c", null ]
];