var _s_d_l__gamecontroller_8h_struct_s_d_l___game_controller_button_bind_8value_8hat =
[
    [ "hat", "_s_d_l__gamecontroller_8h.html#a46b5e59b2fd342bf8fee10c561958725", null ],
    [ "hat_mask", "_s_d_l__gamecontroller_8h.html#af86548f91cfa7062ac716d51f5de48a0", null ]
];