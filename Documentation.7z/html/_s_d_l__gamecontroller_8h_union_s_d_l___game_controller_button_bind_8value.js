var _s_d_l__gamecontroller_8h_union_s_d_l___game_controller_button_bind_8value =
[
    [ "axis", "_s_d_l__gamecontroller_8h.html#a433169d5d9bcbb6d43f0d288e68f0cad", null ],
    [ "button", "_s_d_l__gamecontroller_8h.html#ace50a09343724eb82df11390e2c1de18", null ],
    [ "hat", "_s_d_l__gamecontroller_8h.html#a46b5e59b2fd342bf8fee10c561958725", null ]
];