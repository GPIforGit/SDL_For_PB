var _s_d_l__gesture_8h =
[
    [ "SDL_GestureID", "_s_d_l__gesture_8h.html#a6c06ab0de82701c94809da9739ff8ac3", null ],
    [ "SDL_LoadDollarTemplates", "_s_d_l__gesture_8h.html#a83cbaebec0c418b2fc08bbfeeed7d526", null ],
    [ "SDL_RecordGesture", "_s_d_l__gesture_8h.html#ad06776e2e199d5d48e466a0ecbbb06c3", null ],
    [ "SDL_SaveAllDollarTemplates", "_s_d_l__gesture_8h.html#ad37b554c91a5fffe3fc1dc3094db1b89", null ],
    [ "SDL_SaveDollarTemplate", "_s_d_l__gesture_8h.html#acef0242f4c4b7401509bc533864629ad", null ]
];