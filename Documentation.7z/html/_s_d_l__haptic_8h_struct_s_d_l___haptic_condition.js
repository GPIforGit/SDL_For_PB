var _s_d_l__haptic_8h_struct_s_d_l___haptic_condition =
[
    [ "button", "_s_d_l__haptic_8h.html#a9dab31b41646c5d046ea33d0cfb3794a", null ],
    [ "center", "_s_d_l__haptic_8h.html#a28fd31ca00c3317c065d75a364a65c37", null ],
    [ "deadband", "_s_d_l__haptic_8h.html#a255b46ed67f0237c08b4d2f4cd62665d", null ],
    [ "delay", "_s_d_l__haptic_8h.html#a069408e960d0f2ba482421f2dd2ec003", null ],
    [ "direction", "_s_d_l__haptic_8h.html#a9fe6fc39233e26d6c0705ae77e43d96c", null ],
    [ "interval", "_s_d_l__haptic_8h.html#a263a60513b1bdb1e91b28bd2e128e9d4", null ],
    [ "left_coeff", "_s_d_l__haptic_8h.html#add2cf04cbb890bd65f148d14a299fa96", null ],
    [ "left_sat", "_s_d_l__haptic_8h.html#a688464086e8f5b3fb30c63c687c90fd6", null ],
    [ "length", "_s_d_l__haptic_8h.html#afbde362d49894774c8b9c9e85ac0a913", null ],
    [ "right_coeff", "_s_d_l__haptic_8h.html#aba08b5cf32eaa731813117458dca7710", null ],
    [ "right_sat", "_s_d_l__haptic_8h.html#ac923a3cfe907fc31483f4103516bf280", null ],
    [ "type", "_s_d_l__haptic_8h.html#a8db4a3e9f29940892f2773bca31c74e1", null ]
];