var _s_d_l__haptic_8h_struct_s_d_l___haptic_constant =
[
    [ "attack_length", "_s_d_l__haptic_8h.html#ac1af5d594e082747b14fa520f74764c0", null ],
    [ "attack_level", "_s_d_l__haptic_8h.html#accde1dae084b0e3b5027c7731cde9080", null ],
    [ "button", "_s_d_l__haptic_8h.html#a9dab31b41646c5d046ea33d0cfb3794a", null ],
    [ "delay", "_s_d_l__haptic_8h.html#a069408e960d0f2ba482421f2dd2ec003", null ],
    [ "direction", "_s_d_l__haptic_8h.html#a9fe6fc39233e26d6c0705ae77e43d96c", null ],
    [ "fade_length", "_s_d_l__haptic_8h.html#a576ff5ee847dd20a8f1c4a69ce09ba79", null ],
    [ "fade_level", "_s_d_l__haptic_8h.html#a03b48c5ffd631a0f35741e1aa7f482dd", null ],
    [ "interval", "_s_d_l__haptic_8h.html#a263a60513b1bdb1e91b28bd2e128e9d4", null ],
    [ "length", "_s_d_l__haptic_8h.html#afbde362d49894774c8b9c9e85ac0a913", null ],
    [ "level", "_s_d_l__haptic_8h.html#adf1b5bc92984a2dbc520fb3469f40393", null ],
    [ "type", "_s_d_l__haptic_8h.html#a8db4a3e9f29940892f2773bca31c74e1", null ]
];