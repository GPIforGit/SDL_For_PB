var _s_d_l__haptic_8h_struct_s_d_l___haptic_direction =
[
    [ "dir", "_s_d_l__haptic_8h.html#af541745706da7d1806c89885b237aada", null ],
    [ "type", "_s_d_l__haptic_8h.html#a56e09a4f535671f304573b820c5ca945", null ]
];