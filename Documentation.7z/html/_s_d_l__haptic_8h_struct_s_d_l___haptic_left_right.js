var _s_d_l__haptic_8h_struct_s_d_l___haptic_left_right =
[
    [ "large_magnitude", "_s_d_l__haptic_8h.html#a7ddbab8f75202e09f535a9fa6217f129", null ],
    [ "length", "_s_d_l__haptic_8h.html#afbde362d49894774c8b9c9e85ac0a913", null ],
    [ "small_magnitude", "_s_d_l__haptic_8h.html#a801da1244b77fa4181c5cd5e77553031", null ],
    [ "type", "_s_d_l__haptic_8h.html#a8db4a3e9f29940892f2773bca31c74e1", null ]
];