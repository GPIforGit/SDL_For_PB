var _s_d_l__haptic_8h_union_s_d_l___haptic_effect =
[
    [ "condition", "_s_d_l__haptic_8h.html#af8fd644eaf678d5400af856cba7d235b", null ],
    [ "constant", "_s_d_l__haptic_8h.html#ad87e37f1a81c2ae7f4d6f4adb91ccbb3", null ],
    [ "custom", "_s_d_l__haptic_8h.html#a0f40180fec16fe524abd712def126ca1", null ],
    [ "leftright", "_s_d_l__haptic_8h.html#a90d9294f9978f6f71d57e7b4a89bee7f", null ],
    [ "periodic", "_s_d_l__haptic_8h.html#a884ed8463cf22d8ea337a2b0f67e2d5d", null ],
    [ "ramp", "_s_d_l__haptic_8h.html#a7292694427f98b535d05484ee7b3ca45", null ],
    [ "type", "_s_d_l__haptic_8h.html#a8db4a3e9f29940892f2773bca31c74e1", null ]
];