var _s_d_l__joystick_8h_struct_s_d_l___joystick_g_u_i_d =
[
    [ "data", "_s_d_l__joystick_8h.html#a579f6b5bb5c13d1007beee0f034b8a96", null ]
];