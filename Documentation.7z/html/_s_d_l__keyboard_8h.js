var _s_d_l__keyboard_8h =
[
    [ "SDL_Keysym", "_s_d_l__keyboard_8h.html#struct_s_d_l___keysym", [
      [ "mod", "_s_d_l__keyboard_8h.html#a09294cbc86473d2bcb27513748b81aec", null ],
      [ "scancode", "_s_d_l__keyboard_8h.html#a9c8d3b45ebf0a9f0673325d40755c066", null ],
      [ "sym", "_s_d_l__keyboard_8h.html#a20cf23ed00a5cd751fa49ad19e93305a", null ],
      [ "unused", "_s_d_l__keyboard_8h.html#acdefb820f1317fee3507aa00d3d77468", null ]
    ] ],
    [ "SDL_GetKeyboardFocus", "_s_d_l__keyboard_8h.html#a20cb9d78980660f2f97f83e9080a9791", null ],
    [ "SDL_GetKeyboardState", "_s_d_l__keyboard_8h.html#add4d65672474cedfbfe9f3d9c2972aa8", null ],
    [ "SDL_GetKeyFromName", "_s_d_l__keyboard_8h.html#ad4d4e79f117a9092ec269601c5423337", null ],
    [ "SDL_GetKeyFromScancode", "_s_d_l__keyboard_8h.html#aa74e6944ede98feeb09408fd97aaad57", null ],
    [ "SDL_GetKeyName", "_s_d_l__keyboard_8h.html#a5d30971127cd386655b891f429b76fe9", null ],
    [ "SDL_GetModState", "_s_d_l__keyboard_8h.html#a7b2ee63de74c442ac456cac9db5f8ed0", null ],
    [ "SDL_GetScancodeFromKey", "_s_d_l__keyboard_8h.html#a36216054a385bea6898a35ded18d9c0f", null ],
    [ "SDL_GetScancodeFromName", "_s_d_l__keyboard_8h.html#a0cb32dd58d3dc5b77c9daf0b6000f93c", null ],
    [ "SDL_GetScancodeName", "_s_d_l__keyboard_8h.html#ad81526318501fd88c503491909d9c07e", null ],
    [ "SDL_HasScreenKeyboardSupport", "_s_d_l__keyboard_8h.html#a106356274c192b53844c8f1a821b00d7", null ],
    [ "SDL_IsScreenKeyboardShown", "_s_d_l__keyboard_8h.html#a92f5b73c7b71efeb68f5e9616cb918b7", null ],
    [ "SDL_IsTextInputActive", "_s_d_l__keyboard_8h.html#a6c84ed1daac21f8224d43bcb9d5bc597", null ],
    [ "SDL_SetModState", "_s_d_l__keyboard_8h.html#a705c85881304eab01f00abeca2ef5846", null ],
    [ "SDL_SetTextInputRect", "_s_d_l__keyboard_8h.html#a949fd9d16d5156a9d5aa0dc74580dbae", null ],
    [ "SDL_StartTextInput", "_s_d_l__keyboard_8h.html#ab2c8474b9a8b6d07cae4f8eceab38870", null ],
    [ "SDL_StopTextInput", "_s_d_l__keyboard_8h.html#ab08b914cdfb2eaed26165cb2f6b110ec", null ]
];