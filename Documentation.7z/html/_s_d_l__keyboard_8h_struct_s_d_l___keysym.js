var _s_d_l__keyboard_8h_struct_s_d_l___keysym =
[
    [ "mod", "_s_d_l__keyboard_8h.html#a09294cbc86473d2bcb27513748b81aec", null ],
    [ "scancode", "_s_d_l__keyboard_8h.html#a9c8d3b45ebf0a9f0673325d40755c066", null ],
    [ "sym", "_s_d_l__keyboard_8h.html#a20cf23ed00a5cd751fa49ad19e93305a", null ],
    [ "unused", "_s_d_l__keyboard_8h.html#acdefb820f1317fee3507aa00d3d77468", null ]
];