var _s_d_l__loadso_8h =
[
    [ "SDL_LoadFunction", "_s_d_l__loadso_8h.html#a926a605bda55d8d3d66ff6389bc98941", null ],
    [ "SDL_LoadObject", "_s_d_l__loadso_8h.html#a278c5f3a6bb4f141680ef164e94b12b0", null ],
    [ "SDL_UnloadObject", "_s_d_l__loadso_8h.html#a041e43c276cb826c2034eff220be7fe4", null ]
];