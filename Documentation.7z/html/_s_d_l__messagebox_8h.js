var _s_d_l__messagebox_8h =
[
    [ "SDL_MessageBoxButtonData", "_s_d_l__messagebox_8h.html#struct_s_d_l___message_box_button_data", [
      [ "buttonid", "_s_d_l__messagebox_8h.html#a0a58b3764551f49ae76eb734277e547d", null ],
      [ "flags", "_s_d_l__messagebox_8h.html#a048097c5cc2146ce1ff2450684f1b51c", null ],
      [ "text", "_s_d_l__messagebox_8h.html#a16343090e80c4472521560f30113d96c", null ]
    ] ],
    [ "SDL_MessageBoxColor", "_s_d_l__messagebox_8h.html#struct_s_d_l___message_box_color", [
      [ "b", "_s_d_l__messagebox_8h.html#a3d03a0372246e40434fc7a8a928c1e92", null ],
      [ "g", "_s_d_l__messagebox_8h.html#ab4c6f97b95a6d0a8058a62eab9c78c43", null ],
      [ "r", "_s_d_l__messagebox_8h.html#a91b464c8eae5ece8465e150e16086acd", null ]
    ] ],
    [ "SDL_MessageBoxColorScheme", "_s_d_l__messagebox_8h.html#struct_s_d_l___message_box_color_scheme", [
      [ "colors", "_s_d_l__messagebox_8h.html#aac26fca7ad16ef80af11b8afa9f02943", null ]
    ] ],
    [ "SDL_MessageBoxData", "_s_d_l__messagebox_8h.html#struct_s_d_l___message_box_data", [
      [ "buttons", "_s_d_l__messagebox_8h.html#a5d024a90e0db32dee923d8c873118225", null ],
      [ "colorScheme", "_s_d_l__messagebox_8h.html#afcad43ea8520ac57b30b35bee0077618", null ],
      [ "flags", "_s_d_l__messagebox_8h.html#a048097c5cc2146ce1ff2450684f1b51c", null ],
      [ "message", "_s_d_l__messagebox_8h.html#a254bf0858da09c96a48daf64404eb4f8", null ],
      [ "numbuttons", "_s_d_l__messagebox_8h.html#adff7d306bb56e132b0060191672c9525", null ],
      [ "title", "_s_d_l__messagebox_8h.html#a8214780964530800368b406c681fd1d9", null ],
      [ "window", "_s_d_l__messagebox_8h.html#aaa8e409e04dcf575ef63fd5fb3db06f9", null ]
    ] ],
    [ "SDL_MessageBoxButtonFlags", "_s_d_l__messagebox_8h.html#ad21beffe204426be6efbf4990c916ad0", [
      [ "SDL_MESSAGEBOX_BUTTON_RETURNKEY_DEFAULT", "_s_d_l__messagebox_8h.html#ad21beffe204426be6efbf4990c916ad0a67ea775510f7c29ebf0a6448ed01b842", null ],
      [ "SDL_MESSAGEBOX_BUTTON_ESCAPEKEY_DEFAULT", "_s_d_l__messagebox_8h.html#ad21beffe204426be6efbf4990c916ad0aa4afee827b33dd88c00c00eef9c9b46b", null ]
    ] ],
    [ "SDL_MessageBoxColorType", "_s_d_l__messagebox_8h.html#a75e562d38bc214725e01f4f829bc1567", [
      [ "SDL_MESSAGEBOX_COLOR_BACKGROUND", "_s_d_l__messagebox_8h.html#a75e562d38bc214725e01f4f829bc1567a9a2a6e8259fe737efb5c5fc71e71b67f", null ],
      [ "SDL_MESSAGEBOX_COLOR_TEXT", "_s_d_l__messagebox_8h.html#a75e562d38bc214725e01f4f829bc1567aa6e69e6abffa48dba8366ca4c343bd37", null ],
      [ "SDL_MESSAGEBOX_COLOR_BUTTON_BORDER", "_s_d_l__messagebox_8h.html#a75e562d38bc214725e01f4f829bc1567add5517e7916c5aad3f9582d8d9e736ce", null ],
      [ "SDL_MESSAGEBOX_COLOR_BUTTON_BACKGROUND", "_s_d_l__messagebox_8h.html#a75e562d38bc214725e01f4f829bc1567a864f22d6d76293999a83c0ae29bf04e2", null ],
      [ "SDL_MESSAGEBOX_COLOR_BUTTON_SELECTED", "_s_d_l__messagebox_8h.html#a75e562d38bc214725e01f4f829bc1567a8ed458545a3c4f08ff795015a197f678", null ],
      [ "SDL_MESSAGEBOX_COLOR_MAX", "_s_d_l__messagebox_8h.html#a75e562d38bc214725e01f4f829bc1567a0a575b056603e38e844b141c83a44d89", null ]
    ] ],
    [ "SDL_MessageBoxFlags", "_s_d_l__messagebox_8h.html#a97f06819ac610581044fdb93d81eed37", [
      [ "SDL_MESSAGEBOX_ERROR", "_s_d_l__messagebox_8h.html#a97f06819ac610581044fdb93d81eed37a0c3a423a27f14a59ae160a8f145788d6", null ],
      [ "SDL_MESSAGEBOX_WARNING", "_s_d_l__messagebox_8h.html#a97f06819ac610581044fdb93d81eed37a90a65bab036b0156ddec9d8c7e41a2ce", null ],
      [ "SDL_MESSAGEBOX_INFORMATION", "_s_d_l__messagebox_8h.html#a97f06819ac610581044fdb93d81eed37aa5c724184320aa258788481e9ad6d814", null ],
      [ "SDL_MESSAGEBOX_BUTTONS_LEFT_TO_RIGHT", "_s_d_l__messagebox_8h.html#a97f06819ac610581044fdb93d81eed37aca1b8c594588c656e940a8447a862d08", null ],
      [ "SDL_MESSAGEBOX_BUTTONS_RIGHT_TO_LEFT", "_s_d_l__messagebox_8h.html#a97f06819ac610581044fdb93d81eed37a9786e79c1efa0c7ea96da7a08af9a24d", null ]
    ] ],
    [ "SDL_ShowMessageBox", "_s_d_l__messagebox_8h.html#a5100de0969e90cc8f82c256287136e05", null ],
    [ "SDL_ShowSimpleMessageBox", "_s_d_l__messagebox_8h.html#a34d06cce5c7b8d25812da0306696de32", null ]
];