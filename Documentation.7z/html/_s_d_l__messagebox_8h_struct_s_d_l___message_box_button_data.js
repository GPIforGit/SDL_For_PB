var _s_d_l__messagebox_8h_struct_s_d_l___message_box_button_data =
[
    [ "buttonid", "_s_d_l__messagebox_8h.html#a0a58b3764551f49ae76eb734277e547d", null ],
    [ "flags", "_s_d_l__messagebox_8h.html#a048097c5cc2146ce1ff2450684f1b51c", null ],
    [ "text", "_s_d_l__messagebox_8h.html#a16343090e80c4472521560f30113d96c", null ]
];