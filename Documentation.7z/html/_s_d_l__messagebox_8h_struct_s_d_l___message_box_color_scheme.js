var _s_d_l__messagebox_8h_struct_s_d_l___message_box_color_scheme =
[
    [ "colors", "_s_d_l__messagebox_8h.html#aac26fca7ad16ef80af11b8afa9f02943", null ]
];