var _s_d_l__messagebox_8h_struct_s_d_l___message_box_data =
[
    [ "buttons", "_s_d_l__messagebox_8h.html#a5d024a90e0db32dee923d8c873118225", null ],
    [ "colorScheme", "_s_d_l__messagebox_8h.html#afcad43ea8520ac57b30b35bee0077618", null ],
    [ "flags", "_s_d_l__messagebox_8h.html#a048097c5cc2146ce1ff2450684f1b51c", null ],
    [ "message", "_s_d_l__messagebox_8h.html#a254bf0858da09c96a48daf64404eb4f8", null ],
    [ "numbuttons", "_s_d_l__messagebox_8h.html#adff7d306bb56e132b0060191672c9525", null ],
    [ "title", "_s_d_l__messagebox_8h.html#a8214780964530800368b406c681fd1d9", null ],
    [ "window", "_s_d_l__messagebox_8h.html#aaa8e409e04dcf575ef63fd5fb3db06f9", null ]
];