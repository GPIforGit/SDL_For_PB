var _s_d_l__metal_8h =
[
    [ "SDL_MetalView", "_s_d_l__metal_8h.html#a0d6413e2d369fbf22f0a2e4ec15bf412", null ],
    [ "SDL_Metal_CreateView", "_s_d_l__metal_8h.html#a3dad1f90d67b2e72ec2f5bfc9e20f54c", null ],
    [ "SDL_Metal_DestroyView", "_s_d_l__metal_8h.html#a262167b535f38dd12f022df81fddb8f5", null ]
];