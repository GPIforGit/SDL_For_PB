var _s_d_l__mixer_8h_struct_mix___chunk =
[
    [ "abuf", "_s_d_l__mixer_8h.html#a1b9f9d5566616dd82aabacd30f680a96", null ],
    [ "alen", "_s_d_l__mixer_8h.html#a5c0100f41d24bd51b2848c064a8d17c3", null ],
    [ "allocated", "_s_d_l__mixer_8h.html#a115235fc25fdf1c03d856bd072b6cead", null ],
    [ "volume", "_s_d_l__mixer_8h.html#a96eebcd662128c3c25b12aed9eb75009", null ]
];