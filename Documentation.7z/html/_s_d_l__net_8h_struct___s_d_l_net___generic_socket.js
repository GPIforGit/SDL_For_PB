var _s_d_l__net_8h_struct___s_d_l_net___generic_socket =
[
    [ "ready", "_s_d_l__net_8h.html#a4adb4fb035eed17910c98225be64ec83", null ]
];