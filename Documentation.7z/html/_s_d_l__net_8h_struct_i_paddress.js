var _s_d_l__net_8h_struct_i_paddress =
[
    [ "host", "_s_d_l__net_8h.html#ae9bb64a134c48a9a082ae28c5b63a873", null ],
    [ "port", "_s_d_l__net_8h.html#a5da1f648d89f6625e9b0db598daf5b21", null ]
];