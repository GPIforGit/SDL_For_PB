var _s_d_l__net_8h_struct_u_d_ppacket =
[
    [ "address", "_s_d_l__net_8h.html#a7c777a5d05c5e96761797620735591cc", null ],
    [ "channel", "_s_d_l__net_8h.html#adf7dff2c57c0da9a4a2b70e3e815be31", null ],
    [ "data", "_s_d_l__net_8h.html#ad331b0aa261a7f644060d14a3dcc6e7d", null ],
    [ "len", "_s_d_l__net_8h.html#afed088663f8704004425cdae2120b9b3", null ],
    [ "maxlen", "_s_d_l__net_8h.html#a245b5bee0d02a20222d815dbeaaac0fb", null ],
    [ "status", "_s_d_l__net_8h.html#a6e27f49150e9a14580fb313cc2777e00", null ]
];