var _s_d_l__pixels_8h_struct_s_d_l___color =
[
    [ "a", "_s_d_l__pixels_8h.html#ababb728b2453c31cab11523817407956", null ],
    [ "b", "_s_d_l__pixels_8h.html#a3d03a0372246e40434fc7a8a928c1e92", null ],
    [ "g", "_s_d_l__pixels_8h.html#ab4c6f97b95a6d0a8058a62eab9c78c43", null ],
    [ "r", "_s_d_l__pixels_8h.html#a91b464c8eae5ece8465e150e16086acd", null ]
];