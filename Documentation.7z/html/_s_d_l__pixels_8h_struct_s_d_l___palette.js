var _s_d_l__pixels_8h_struct_s_d_l___palette =
[
    [ "colors", "_s_d_l__pixels_8h.html#a6ffa1034612a7b59bb47a4614993829f", null ],
    [ "ncolors", "_s_d_l__pixels_8h.html#aeac67cf686cea9cb1d69661714767244", null ],
    [ "refcount", "_s_d_l__pixels_8h.html#a6022c8a609170c7365fb96e83cb2df48", null ],
    [ "version", "_s_d_l__pixels_8h.html#a5d07ecb490ddbe3cdc17e84185b7aeb1", null ]
];