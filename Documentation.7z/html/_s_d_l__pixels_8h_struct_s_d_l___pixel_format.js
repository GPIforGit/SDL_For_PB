var _s_d_l__pixels_8h_struct_s_d_l___pixel_format =
[
    [ "Aloss", "_s_d_l__pixels_8h.html#ade1d0c24b3b8c63cc84549905ca87166", null ],
    [ "Amask", "_s_d_l__pixels_8h.html#a30dce0e46660995b989f2805e2f26218", null ],
    [ "Ashift", "_s_d_l__pixels_8h.html#ae566d85cf2c4eae814322dfec60d8647", null ],
    [ "BitsPerPixel", "_s_d_l__pixels_8h.html#ae2b4f09d6d3567379f04539cd8ae81f4", null ],
    [ "Bloss", "_s_d_l__pixels_8h.html#abe6099b012ba924ee1238f1b83a55e1b", null ],
    [ "Bmask", "_s_d_l__pixels_8h.html#a578b1ec22793f0a21072e4c87f5f0f86", null ],
    [ "Bshift", "_s_d_l__pixels_8h.html#ab91169d28e0ed13ea564a21fd08440d5", null ],
    [ "BytesPerPixel", "_s_d_l__pixels_8h.html#aac593e3f3963d68cd64ca0b58946a121", null ],
    [ "format", "_s_d_l__pixels_8h.html#a564cec93e3c28ae1ff8340e1079ff385", null ],
    [ "Gloss", "_s_d_l__pixels_8h.html#ac44d76ceabdec273921c430afc4baf65", null ],
    [ "Gmask", "_s_d_l__pixels_8h.html#acc0a1bbf72188b17065ddbae7de1a8a5", null ],
    [ "Gshift", "_s_d_l__pixels_8h.html#a537451cb46162b729fbe10b9d2469712", null ],
    [ "next", "_s_d_l__pixels_8h.html#ac7e2744f93a892694f8d360c341c2a3f", null ],
    [ "padding", "_s_d_l__pixels_8h.html#a8e55f9ad80f8d4eaddacf7da94dedcb4", null ],
    [ "palette", "_s_d_l__pixels_8h.html#a142fe8e3220332fc9b38e59d5b7218a3", null ],
    [ "refcount", "_s_d_l__pixels_8h.html#a6022c8a609170c7365fb96e83cb2df48", null ],
    [ "Rloss", "_s_d_l__pixels_8h.html#af7e7eea7b82eee97ee172ea9c119f490", null ],
    [ "Rmask", "_s_d_l__pixels_8h.html#ad72f42bead0db7f2408ae57ea93aa168", null ],
    [ "Rshift", "_s_d_l__pixels_8h.html#a2d79297d36a08f7b9ea9bda330d9eb02", null ]
];