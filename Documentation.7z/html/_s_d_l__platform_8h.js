var _s_d_l__platform_8h =
[
    [ "SDL_GetPlatform", "_s_d_l__platform_8h.html#a55905e7a299221262fc655e785ab2dc7", null ]
];