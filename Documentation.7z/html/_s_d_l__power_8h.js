var _s_d_l__power_8h =
[
    [ "SDL_PowerState", "_s_d_l__power_8h.html#aa6d67208a8d30ececf84b158a2ab7eff", [
      [ "SDL_POWERSTATE_UNKNOWN", "_s_d_l__power_8h.html#aa6d67208a8d30ececf84b158a2ab7effa5c20e9c8a8c455a9ed9c66167ac2df61", null ],
      [ "SDL_POWERSTATE_ON_BATTERY", "_s_d_l__power_8h.html#aa6d67208a8d30ececf84b158a2ab7effa864da7f4b32af694cb94c9ba58dab985", null ],
      [ "SDL_POWERSTATE_NO_BATTERY", "_s_d_l__power_8h.html#aa6d67208a8d30ececf84b158a2ab7effa03bcd1ca770f703d834d67756fdafbeb", null ],
      [ "SDL_POWERSTATE_CHARGING", "_s_d_l__power_8h.html#aa6d67208a8d30ececf84b158a2ab7effa051d2e5681ad1647ff274ef17fc7ca1e", null ],
      [ "SDL_POWERSTATE_CHARGED", "_s_d_l__power_8h.html#aa6d67208a8d30ececf84b158a2ab7effa320ceff2db32f9bc2e1b8d644d1fb0b4", null ]
    ] ],
    [ "SDL_GetPowerInfo", "_s_d_l__power_8h.html#aed0dded691bb8ec94b119a90a1126049", null ]
];