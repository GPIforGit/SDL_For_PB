var _s_d_l__quit_8h =
[
    [ "SDL_QuitRequested", "_s_d_l__quit_8h.html#a28f0e45d1be91312001526ec45d9dc83", null ]
];