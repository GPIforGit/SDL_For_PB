var _s_d_l__rect_8h =
[
    [ "SDL_Point", "_s_d_l__rect_8h.html#struct_s_d_l___point", [
      [ "x", "_s_d_l__rect_8h.html#a6150e0515f7202e2fb518f7206ed97dc", null ],
      [ "y", "_s_d_l__rect_8h.html#a0a2f84ed7838f07779ae24c5a9086d33", null ]
    ] ],
    [ "SDL_FPoint", "_s_d_l__rect_8h.html#struct_s_d_l___f_point", [
      [ "x", "_s_d_l__rect_8h.html#ad0da36b2558901e21e7a30f6c227a45e", null ],
      [ "y", "_s_d_l__rect_8h.html#aa4f0d3eebc3c443f9be81bf48561a217", null ]
    ] ],
    [ "SDL_Rect", "_s_d_l__rect_8h.html#struct_s_d_l___rect", [
      [ "h", "_s_d_l__rect_8h.html#a16611451551e3d15916bae723c3f59f7", null ],
      [ "w", "_s_d_l__rect_8h.html#aac374e320caaadeca4874add33b62af2", null ],
      [ "x", "_s_d_l__rect_8h.html#a6150e0515f7202e2fb518f7206ed97dc", null ],
      [ "y", "_s_d_l__rect_8h.html#a0a2f84ed7838f07779ae24c5a9086d33", null ]
    ] ],
    [ "SDL_FRect", "_s_d_l__rect_8h.html#struct_s_d_l___f_rect", [
      [ "h", "_s_d_l__rect_8h.html#a85f2f1bd58b3b44ffdf3881823393959", null ],
      [ "w", "_s_d_l__rect_8h.html#a56eca241e2896b9f57a79589e76fd24b", null ],
      [ "x", "_s_d_l__rect_8h.html#ad0da36b2558901e21e7a30f6c227a45e", null ],
      [ "y", "_s_d_l__rect_8h.html#aa4f0d3eebc3c443f9be81bf48561a217", null ]
    ] ],
    [ "SDL_EnclosePoints", "_s_d_l__rect_8h.html#afcbb58dbba760b9e6fdb4b5d1ece015c", null ],
    [ "SDL_HasIntersection", "_s_d_l__rect_8h.html#a191ec0b069421d4a36304b475697e847", null ],
    [ "SDL_IntersectRect", "_s_d_l__rect_8h.html#aff8e3dd3b1a25443cd7c8cf02a087290", null ],
    [ "SDL_IntersectRectAndLine", "_s_d_l__rect_8h.html#acdabdcbeb7b7083f94a092daa26ce069", null ],
    [ "SDL_PointInRect", "_s_d_l__rect_8h.html#a2f9708f2739ef234c34e6feda50b4d2c", null ],
    [ "SDL_RectEmpty", "_s_d_l__rect_8h.html#aac0e9b5d3f34baec6a2cde95bb01f49c", null ],
    [ "SDL_RectEquals", "_s_d_l__rect_8h.html#a156979fd3561cf90b87741d11057262a", null ],
    [ "SDL_UnionRect", "_s_d_l__rect_8h.html#a659f2c25335202888408c95195823f9c", null ]
];