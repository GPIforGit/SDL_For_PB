var _s_d_l__rect_8h_struct_s_d_l___f_point =
[
    [ "x", "_s_d_l__rect_8h.html#ad0da36b2558901e21e7a30f6c227a45e", null ],
    [ "y", "_s_d_l__rect_8h.html#aa4f0d3eebc3c443f9be81bf48561a217", null ]
];