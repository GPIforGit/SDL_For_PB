var _s_d_l__rect_8h_struct_s_d_l___point =
[
    [ "x", "_s_d_l__rect_8h.html#a6150e0515f7202e2fb518f7206ed97dc", null ],
    [ "y", "_s_d_l__rect_8h.html#a0a2f84ed7838f07779ae24c5a9086d33", null ]
];