var _s_d_l__rect_8h_struct_s_d_l___rect =
[
    [ "h", "_s_d_l__rect_8h.html#a16611451551e3d15916bae723c3f59f7", null ],
    [ "w", "_s_d_l__rect_8h.html#aac374e320caaadeca4874add33b62af2", null ],
    [ "x", "_s_d_l__rect_8h.html#a6150e0515f7202e2fb518f7206ed97dc", null ],
    [ "y", "_s_d_l__rect_8h.html#a0a2f84ed7838f07779ae24c5a9086d33", null ]
];