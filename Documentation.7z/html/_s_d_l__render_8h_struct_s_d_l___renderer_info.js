var _s_d_l__render_8h_struct_s_d_l___renderer_info =
[
    [ "flags", "_s_d_l__render_8h.html#a048097c5cc2146ce1ff2450684f1b51c", null ],
    [ "max_texture_height", "_s_d_l__render_8h.html#a0660205b899cefb8b2c807dc244296f7", null ],
    [ "max_texture_width", "_s_d_l__render_8h.html#abe1e7efe1a1dae989c33c89e0597493d", null ],
    [ "name", "_s_d_l__render_8h.html#a8f8f80d37794cde9472343e4487ba3eb", null ],
    [ "num_texture_formats", "_s_d_l__render_8h.html#a0cfcc641f2a99b9f5a0e3e3eb5fbbefe", null ],
    [ "texture_formats", "_s_d_l__render_8h.html#ac164ceadcdd8ed21d07370501fffed2c", null ]
];