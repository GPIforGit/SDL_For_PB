var _s_d_l__rwops_8h =
[
    [ "SDL_RWops", "struct_s_d_l___r_wops.html", "struct_s_d_l___r_wops" ],
    [ "SDL_RWops.hidden", "_s_d_l__rwops_8h.html#union_s_d_l___r_wops_8hidden", [
      [ "mem", "_s_d_l__rwops_8h.html#aafc4fc7e48a0710a1dc94ef3e8bc5764", null ],
      [ "unknown", "_s_d_l__rwops_8h.html#aad921d60486366258809553a3db49a4a", null ]
    ] ],
    [ "SDL_RWops.hidden.mem", "_s_d_l__rwops_8h.html#struct_s_d_l___r_wops_8hidden_8mem", [
      [ "base", "_s_d_l__rwops_8h.html#a593616de15330c0fb2d55e55410bf994", null ],
      [ "here", "_s_d_l__rwops_8h.html#a6c92285fa6d3e827b198d120ea3ac674", null ],
      [ "stop", "_s_d_l__rwops_8h.html#aef399b2d446bb37b7c32ad2cc1b6045b", null ]
    ] ],
    [ "SDL_RWops.hidden.unknown", "_s_d_l__rwops_8h.html#struct_s_d_l___r_wops_8hidden_8unknown", [
      [ "data1", "_s_d_l__rwops_8h.html#a89d903bc35dede724fd52c51437ff5fd", null ],
      [ "data2", "_s_d_l__rwops_8h.html#aff9cf2d690d888cb337f6bf4526b6130", null ]
    ] ],
    [ "RW_SEEK_CUR", "_s_d_l__rwops_8h.html#aba5f3b60c197def370ffa2ca1ab1348d", null ],
    [ "RW_SEEK_END", "_s_d_l__rwops_8h.html#a6cf141faabd1b8f2ec3c03cf76eaf553", null ],
    [ "RW_SEEK_SET", "_s_d_l__rwops_8h.html#ac028b032bb8230df64bc6284e04789f5", null ],
    [ "SDL_RWOPS_JNIFILE", "_s_d_l__rwops_8h.html#ad1e973a8b9f9c6cae33f2870c9f76b7d", null ],
    [ "SDL_RWOPS_MEMORY", "_s_d_l__rwops_8h.html#a1120765c20af356803b2beb6709e6749", null ],
    [ "SDL_RWOPS_MEMORY_RO", "_s_d_l__rwops_8h.html#a145dd63b72548f37e2fdd9de8bf15bbc", null ],
    [ "SDL_RWOPS_STDFILE", "_s_d_l__rwops_8h.html#a054a717fd0b1a2f175e2e822e1ecc67d", null ],
    [ "SDL_RWOPS_UNKNOWN", "_s_d_l__rwops_8h.html#abefd1a35086e97620beffc2c069bd97d", null ],
    [ "SDL_RWOPS_WINFILE", "_s_d_l__rwops_8h.html#ad979b58d7905cfd8af0bab9ed97c1685", null ],
    [ "SDL_AllocRW", "_s_d_l__rwops_8h.html#a02d04e13c85cd28706b8c3881c32dd46", null ],
    [ "SDL_FreeRW", "_s_d_l__rwops_8h.html#ac4c87c7bed186ea1a98531164ff1acfa", null ],
    [ "SDL_LoadFile", "_s_d_l__rwops_8h.html#ac259a2d74dfea39864bf3840ee126837", null ],
    [ "SDL_LoadFile_RW", "_s_d_l__rwops_8h.html#ab80a1b522d2fbbae8ed5610d029fcfda", null ],
    [ "SDL_ReadBE16", "_s_d_l__rwops_8h.html#a3cdf85a50e40dc58536930429b7b4d09", null ],
    [ "SDL_ReadBE32", "_s_d_l__rwops_8h.html#af023e134e3ae87b1595306e5faeaab76", null ],
    [ "SDL_ReadBE64", "_s_d_l__rwops_8h.html#a4917dc584d162bc5f28b63843557214e", null ],
    [ "SDL_ReadLE16", "_s_d_l__rwops_8h.html#a7274f5c4b6f22a6b742ec6ef4f9d390b", null ],
    [ "SDL_ReadLE32", "_s_d_l__rwops_8h.html#a8320334c299a3631fd6beb9937c30f04", null ],
    [ "SDL_ReadLE64", "_s_d_l__rwops_8h.html#af7e5d9b56874b8bd3a8a6a0c5393c33d", null ],
    [ "SDL_ReadU8", "_s_d_l__rwops_8h.html#ab864094eb6b80fbf0c77d34ecdde7907", null ],
    [ "SDL_RWclose", "_s_d_l__rwops_8h.html#a4e432d6d008ad176b7653b4797de12e9", null ],
    [ "SDL_RWFromConstMem", "_s_d_l__rwops_8h.html#a51b4be80c4647e8a473b6b9fed03b1a6", null ],
    [ "SDL_RWFromFile", "_s_d_l__rwops_8h.html#aef7e843c3486bd1770667a594aa0b439", null ],
    [ "SDL_RWFromFP", "_s_d_l__rwops_8h.html#abbd4eda76f330b5c4b813238affbe7a8", null ],
    [ "SDL_RWFromMem", "_s_d_l__rwops_8h.html#ae6f34841ce63d08597477558ffc0278e", null ],
    [ "SDL_RWread", "_s_d_l__rwops_8h.html#a7496ce8759fe964ee40cd6fbfa4b82f9", null ],
    [ "SDL_RWseek", "_s_d_l__rwops_8h.html#a2bd3bfec48d375b5e761a5f7f3138766", null ],
    [ "SDL_RWsize", "_s_d_l__rwops_8h.html#ab311e9e01e66dde338349b5988008f79", null ],
    [ "SDL_RWtell", "_s_d_l__rwops_8h.html#aade1cc6bf5cd0972c64f1bc032bdece6", null ],
    [ "SDL_RWwrite", "_s_d_l__rwops_8h.html#ada3c6d29d2fc5f0367abdcbfc2f2896a", null ],
    [ "SDL_WriteBE16", "_s_d_l__rwops_8h.html#ab84ea778a5f8f76cd73a52216c2c08f5", null ],
    [ "SDL_WriteBE32", "_s_d_l__rwops_8h.html#a5debf04eeed819018ddd9a2f70d32c89", null ],
    [ "SDL_WriteBE64", "_s_d_l__rwops_8h.html#a0422f79e1889750cf99310e968cb76fc", null ],
    [ "SDL_WriteLE16", "_s_d_l__rwops_8h.html#aa4a7df8d967c5751e3f0974743b9c2d4", null ],
    [ "SDL_WriteLE32", "_s_d_l__rwops_8h.html#a84f37961925773fe8b06ea09ed144568", null ],
    [ "SDL_WriteLE64", "_s_d_l__rwops_8h.html#ae4f9b45fbb3bf4a40f3f308419307e6b", null ],
    [ "SDL_WriteU8", "_s_d_l__rwops_8h.html#a07c817f8360ddc8c8983d12373306555", null ]
];