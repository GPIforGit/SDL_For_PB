var _s_d_l__rwops_8h_struct_s_d_l___r_wops_8hidden_8mem =
[
    [ "base", "_s_d_l__rwops_8h.html#a593616de15330c0fb2d55e55410bf994", null ],
    [ "here", "_s_d_l__rwops_8h.html#a6c92285fa6d3e827b198d120ea3ac674", null ],
    [ "stop", "_s_d_l__rwops_8h.html#aef399b2d446bb37b7c32ad2cc1b6045b", null ]
];