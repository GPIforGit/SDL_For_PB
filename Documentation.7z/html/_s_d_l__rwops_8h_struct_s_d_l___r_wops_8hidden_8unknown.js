var _s_d_l__rwops_8h_struct_s_d_l___r_wops_8hidden_8unknown =
[
    [ "data1", "_s_d_l__rwops_8h.html#a89d903bc35dede724fd52c51437ff5fd", null ],
    [ "data2", "_s_d_l__rwops_8h.html#aff9cf2d690d888cb337f6bf4526b6130", null ]
];