var _s_d_l__rwops_8h_union_s_d_l___r_wops_8hidden =
[
    [ "mem", "_s_d_l__rwops_8h.html#aafc4fc7e48a0710a1dc94ef3e8bc5764", null ],
    [ "unknown", "_s_d_l__rwops_8h.html#aad921d60486366258809553a3db49a4a", null ]
];