var _s_d_l__shape_8h =
[
    [ "SDL_WindowShapeParams", "_s_d_l__shape_8h.html#union_s_d_l___window_shape_params", [
      [ "binarizationCutoff", "_s_d_l__shape_8h.html#a4cd674dc6ce063fa26ee9251ec4c962e", null ],
      [ "colorKey", "_s_d_l__shape_8h.html#a76bfee99df3e09547f00aed7ca18d4ad", null ]
    ] ],
    [ "SDL_WindowShapeMode", "_s_d_l__shape_8h.html#struct_s_d_l___window_shape_mode", [
      [ "mode", "_s_d_l__shape_8h.html#ab4a7dfd410934bebf80e105f6fa72b74", null ],
      [ "parameters", "_s_d_l__shape_8h.html#ade9cf0ce2577f5478fb4015dc15347bb", null ]
    ] ],
    [ "SDL_INVALID_SHAPE_ARGUMENT", "_s_d_l__shape_8h.html#a1cfaf1e1a560ef7f68f59f46a9a0b1fd", null ],
    [ "SDL_NONSHAPEABLE_WINDOW", "_s_d_l__shape_8h.html#a45e50a0ce349a4e200338d634fa73de5", null ],
    [ "SDL_SHAPEMODEALPHA", "_s_d_l__shape_8h.html#af8e3c7bdeca58eb82cb8faed8d385cdc", null ],
    [ "SDL_WINDOW_LACKS_SHAPE", "_s_d_l__shape_8h.html#aa7306c8f1a1b87b398a9842383303232", null ],
    [ "WindowShapeMode", "_s_d_l__shape_8h.html#aa30948f2699e316a43b740eccebe5c20", [
      [ "ShapeModeDefault", "_s_d_l__shape_8h.html#aa30948f2699e316a43b740eccebe5c20aca1bc38c9b5179cbed0e9e176cd84d9e", null ],
      [ "ShapeModeBinarizeAlpha", "_s_d_l__shape_8h.html#aa30948f2699e316a43b740eccebe5c20a0ba1cff6129858a1136728ffdc787926", null ],
      [ "ShapeModeReverseBinarizeAlpha", "_s_d_l__shape_8h.html#aa30948f2699e316a43b740eccebe5c20ae478c81ede522586674806541e145993", null ],
      [ "ShapeModeColorKey", "_s_d_l__shape_8h.html#aa30948f2699e316a43b740eccebe5c20a1d3ca52e90d5b3086e22120c2899f214", null ]
    ] ],
    [ "SDL_CreateShapedWindow", "_s_d_l__shape_8h.html#a5a7bed102a3db4d91e6a8e21be0f9950", null ],
    [ "SDL_GetShapedWindowMode", "_s_d_l__shape_8h.html#a64dba6f6440cf6984d8da868fd758711", null ],
    [ "SDL_IsShapedWindow", "_s_d_l__shape_8h.html#a28630f0f6b298bac4d0efe850d7d327e", null ],
    [ "SDL_SetWindowShape", "_s_d_l__shape_8h.html#a90d52818802235df9689922be5a4cf5a", null ]
];