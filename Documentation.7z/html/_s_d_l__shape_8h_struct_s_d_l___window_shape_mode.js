var _s_d_l__shape_8h_struct_s_d_l___window_shape_mode =
[
    [ "mode", "_s_d_l__shape_8h.html#ab4a7dfd410934bebf80e105f6fa72b74", null ],
    [ "parameters", "_s_d_l__shape_8h.html#ade9cf0ce2577f5478fb4015dc15347bb", null ]
];