var _s_d_l__shape_8h_union_s_d_l___window_shape_params =
[
    [ "binarizationCutoff", "_s_d_l__shape_8h.html#a4cd674dc6ce063fa26ee9251ec4c962e", null ],
    [ "colorKey", "_s_d_l__shape_8h.html#a76bfee99df3e09547f00aed7ca18d4ad", null ]
];