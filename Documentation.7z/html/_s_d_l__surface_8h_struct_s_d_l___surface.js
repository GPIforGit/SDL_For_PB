var _s_d_l__surface_8h_struct_s_d_l___surface =
[
    [ "clip_rect", "_s_d_l__surface_8h.html#ada87d50bed22f849936519c4912a5a98", null ],
    [ "flags", "_s_d_l__surface_8h.html#a048097c5cc2146ce1ff2450684f1b51c", null ],
    [ "format", "_s_d_l__surface_8h.html#a9d191a5bbd871cd7b4ded2158b4f61e8", null ],
    [ "h", "_s_d_l__surface_8h.html#a16611451551e3d15916bae723c3f59f7", null ],
    [ "lock_data", "_s_d_l__surface_8h.html#aae9edc33317dc7ff7c41d40fae6bb5c3", null ],
    [ "locked", "_s_d_l__surface_8h.html#a3656313f0cb42dffd0c00864ca333c25", null ],
    [ "map", "_s_d_l__surface_8h.html#a6305e21db64c3e35a648981e733414b3", null ],
    [ "pitch", "_s_d_l__surface_8h.html#a05c8b22d2905f7a52fa31b13f85c70f3", null ],
    [ "pixels", "_s_d_l__surface_8h.html#aaf78c2553b191735d6902cafb68a92ff", null ],
    [ "refcount", "_s_d_l__surface_8h.html#a6022c8a609170c7365fb96e83cb2df48", null ],
    [ "userdata", "_s_d_l__surface_8h.html#afd0ffb02780e738d4c0a10ab833b7834", null ],
    [ "w", "_s_d_l__surface_8h.html#aac374e320caaadeca4874add33b62af2", null ]
];