var _s_d_l__system_8h =
[
    [ "SDL_IsTablet", "_s_d_l__system_8h.html#a211a146233e8e37c64185105132e6257", null ],
    [ "SDL_OnApplicationDidBecomeActive", "_s_d_l__system_8h.html#a3e224d35ef257b2a7583e02ac9dabe90", null ],
    [ "SDL_OnApplicationDidEnterBackground", "_s_d_l__system_8h.html#af10116e8b6a71fb584a0cec7e582f9ec", null ],
    [ "SDL_OnApplicationDidReceiveMemoryWarning", "_s_d_l__system_8h.html#ae0ff6644972f065a06072426a0f1691f", null ],
    [ "SDL_OnApplicationWillEnterForeground", "_s_d_l__system_8h.html#a4292c3354aed782e634ee116d23cfd26", null ],
    [ "SDL_OnApplicationWillResignActive", "_s_d_l__system_8h.html#ad8e8c246a466b29a84a9018cb0803a55", null ],
    [ "SDL_OnApplicationWillTerminate", "_s_d_l__system_8h.html#ae3e44a610898157232a49a754fc3ab9a", null ]
];