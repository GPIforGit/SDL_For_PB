var _s_d_l__timer_8h =
[
    [ "SDL_TICKS_PASSED", "_s_d_l__timer_8h.html#a5cc109e24ba0c46f6becb28353cd8921", null ],
    [ "SDL_TimerCallback", "_s_d_l__timer_8h.html#a3c5c867db975d245e4a82fcf0cd7de80", null ],
    [ "SDL_TimerID", "_s_d_l__timer_8h.html#a412e8ff8a6c89615ba8f9486b292213a", null ],
    [ "SDL_AddTimer", "_s_d_l__timer_8h.html#a56ceea49587e3fa5796b2e4bf85603b8", null ],
    [ "SDL_Delay", "_s_d_l__timer_8h.html#ae8050b95373b95249064467592ab4e21", null ],
    [ "SDL_GetPerformanceCounter", "_s_d_l__timer_8h.html#a2dbeb63c4f0564811a4adf3938808977", null ],
    [ "SDL_GetPerformanceFrequency", "_s_d_l__timer_8h.html#a507ebea12e31dacc9f85f7d9febe0efb", null ],
    [ "SDL_GetTicks", "_s_d_l__timer_8h.html#a0b9bc71d6287e0ffafdc3419760fe2b3", null ],
    [ "SDL_RemoveTimer", "_s_d_l__timer_8h.html#afe8d418e59a24ae6ad820b92137ab9b2", null ]
];