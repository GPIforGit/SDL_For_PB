var _s_d_l__touch_8h =
[
    [ "SDL_Finger", "_s_d_l__touch_8h.html#struct_s_d_l___finger", [
      [ "id", "_s_d_l__touch_8h.html#a06eb039fdc8749dc760a21024c9068e2", null ],
      [ "pressure", "_s_d_l__touch_8h.html#ac870e1249bab4a2a68cc4126761d24ef", null ],
      [ "x", "_s_d_l__touch_8h.html#ad0da36b2558901e21e7a30f6c227a45e", null ],
      [ "y", "_s_d_l__touch_8h.html#aa4f0d3eebc3c443f9be81bf48561a217", null ]
    ] ],
    [ "SDL_MOUSE_TOUCHID", "_s_d_l__touch_8h.html#a014b4d4442ccb50ec471a7a6081b75d0", null ],
    [ "SDL_TOUCH_MOUSEID", "_s_d_l__touch_8h.html#ac24e2ec23c2ac1675fec8f327ef45efe", null ],
    [ "SDL_FingerID", "_s_d_l__touch_8h.html#a5fa58141f78415ca09645af359ad2250", null ],
    [ "SDL_TouchID", "_s_d_l__touch_8h.html#a10f5f86abe4ea8308a8706bd5d3b337a", null ],
    [ "SDL_TouchDeviceType", "_s_d_l__touch_8h.html#a63f6b605841f681e036a96d9b2790cff", [
      [ "SDL_TOUCH_DEVICE_INVALID", "_s_d_l__touch_8h.html#a63f6b605841f681e036a96d9b2790cffae544a4f823bceaa24188c6ab960da300", null ],
      [ "SDL_TOUCH_DEVICE_DIRECT", "_s_d_l__touch_8h.html#a63f6b605841f681e036a96d9b2790cffab39ea53b15fce0d49c796c8ca5515863", null ],
      [ "SDL_TOUCH_DEVICE_INDIRECT_ABSOLUTE", "_s_d_l__touch_8h.html#a63f6b605841f681e036a96d9b2790cffa0715f9019e2a5180a76eb3a8f90d4f5e", null ],
      [ "SDL_TOUCH_DEVICE_INDIRECT_RELATIVE", "_s_d_l__touch_8h.html#a63f6b605841f681e036a96d9b2790cffad8c3585eabc32e6dcccc7726f4c99505", null ]
    ] ],
    [ "SDL_GetNumTouchDevices", "_s_d_l__touch_8h.html#a14a41a2964ddf868a180e42ccfd441d1", null ],
    [ "SDL_GetNumTouchFingers", "_s_d_l__touch_8h.html#a7dcd1494c8dd433b7ef7b24c2926e721", null ],
    [ "SDL_GetTouchDevice", "_s_d_l__touch_8h.html#af23f09dc79eace93cdc8dd770eed0d0a", null ],
    [ "SDL_GetTouchDeviceType", "_s_d_l__touch_8h.html#acb47d9bf9103c6c039127cea040d89a7", null ],
    [ "SDL_GetTouchFinger", "_s_d_l__touch_8h.html#a50902a3c1e4dba0b82cb73cb786dae41", null ]
];