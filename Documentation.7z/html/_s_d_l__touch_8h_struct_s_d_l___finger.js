var _s_d_l__touch_8h_struct_s_d_l___finger =
[
    [ "id", "_s_d_l__touch_8h.html#a06eb039fdc8749dc760a21024c9068e2", null ],
    [ "pressure", "_s_d_l__touch_8h.html#ac870e1249bab4a2a68cc4126761d24ef", null ],
    [ "x", "_s_d_l__touch_8h.html#ad0da36b2558901e21e7a30f6c227a45e", null ],
    [ "y", "_s_d_l__touch_8h.html#aa4f0d3eebc3c443f9be81bf48561a217", null ]
];