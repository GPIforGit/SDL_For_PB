var _s_d_l__version_8h =
[
    [ "SDL_version", "_s_d_l__version_8h.html#struct_s_d_l__version", [
      [ "major", "_s_d_l__version_8h.html#a302f1b7284c3bcdfa0dee1aa267b955e", null ],
      [ "minor", "_s_d_l__version_8h.html#a8eb06ff08bc41ff4eed7c42fc8b40d50", null ],
      [ "patch", "_s_d_l__version_8h.html#af8399ce0bb7205f4761fa050d33ea71e", null ]
    ] ],
    [ "SDL_COMPILEDVERSION", "_s_d_l__version_8h.html#a75227c9b9ca2b4015e4697971712f16c", null ],
    [ "SDL_MAJOR_VERSION", "_s_d_l__version_8h.html#a8fc808626be61507ade364b399f81468", null ],
    [ "SDL_MINOR_VERSION", "_s_d_l__version_8h.html#a2dd98e1cec119d54322cd9c8ea685c5c", null ],
    [ "SDL_PATCHLEVEL", "_s_d_l__version_8h.html#a84a0602cb43e6d9cefbdc119336019d5", null ],
    [ "SDL_VERSION", "_s_d_l__version_8h.html#a7154bc5c2a95a644b5187e4225cdcbd0", null ],
    [ "SDL_VERSION_ATLEAST", "_s_d_l__version_8h.html#a44836f955b961ba74c8c5125af4c9b91", null ],
    [ "SDL_VERSIONNUM", "_s_d_l__version_8h.html#af77ec4d486c3401e48689a016d304e73", null ],
    [ "SDL_GetRevision", "_s_d_l__version_8h.html#a6b6844eae68e68d6f91bc3d8d786cf47", null ],
    [ "SDL_GetRevisionNumber", "_s_d_l__version_8h.html#a20fb5e0316095763c8b8c78afcfa0be2", null ],
    [ "SDL_GetVersion", "_s_d_l__version_8h.html#a4204ecbb600f51ee50515979e60bf8f3", null ]
];