var _s_d_l__version_8h_struct_s_d_l__version =
[
    [ "major", "_s_d_l__version_8h.html#a302f1b7284c3bcdfa0dee1aa267b955e", null ],
    [ "minor", "_s_d_l__version_8h.html#a8eb06ff08bc41ff4eed7c42fc8b40d50", null ],
    [ "patch", "_s_d_l__version_8h.html#af8399ce0bb7205f4761fa050d33ea71e", null ]
];