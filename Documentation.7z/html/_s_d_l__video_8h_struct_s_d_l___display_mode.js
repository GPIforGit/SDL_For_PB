var _s_d_l__video_8h_struct_s_d_l___display_mode =
[
    [ "driverdata", "_s_d_l__video_8h.html#a9171ccac35ae6bd1b4984ad1166a8743", null ],
    [ "format", "_s_d_l__video_8h.html#a564cec93e3c28ae1ff8340e1079ff385", null ],
    [ "h", "_s_d_l__video_8h.html#a16611451551e3d15916bae723c3f59f7", null ],
    [ "refresh_rate", "_s_d_l__video_8h.html#a1885d5e794c0f216ec6dfdeb5933e4b5", null ],
    [ "w", "_s_d_l__video_8h.html#aac374e320caaadeca4874add33b62af2", null ]
];