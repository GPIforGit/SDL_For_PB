var searchData=
[
  ['r_366',['r',['../_s_d_l__messagebox_8h.html#a91b464c8eae5ece8465e150e16086acd',1,'SDL_MessageBoxColor::r()'],['../_s_d_l__pixels_8h.html#a91b464c8eae5ece8465e150e16086acd',1,'SDL_Color::r()']]],
  ['ramp_367',['ramp',['../_s_d_l__haptic_8h.html#a7292694427f98b535d05484ee7b3ca45',1,'SDL_HapticEffect']]],
  ['rate_5fincr_368',['rate_incr',['../_s_d_l__audio_8h.html#aa84e79f31da7eaa8715492a7655fc12e',1,'SDL_AudioCVT']]],
  ['ready_369',['ready',['../_s_d_l__net_8h.html#a4adb4fb035eed17910c98225be64ec83',1,'_SDLNet_GenericSocket']]],
  ['refcount_370',['refcount',['../_s_d_l__pixels_8h.html#a6022c8a609170c7365fb96e83cb2df48',1,'SDL_Palette::refcount()'],['../_s_d_l__pixels_8h.html#a6022c8a609170c7365fb96e83cb2df48',1,'SDL_PixelFormat::refcount()'],['../_s_d_l__surface_8h.html#a6022c8a609170c7365fb96e83cb2df48',1,'SDL_Surface::refcount()']]],
  ['refresh_5frate_371',['refresh_rate',['../_s_d_l__video_8h.html#a1885d5e794c0f216ec6dfdeb5933e4b5',1,'SDL_DisplayMode']]],
  ['repeat_372',['repeat',['../_s_d_l__events_8h.html#a719e1ec1b2969d941426593f9822ef6d',1,'SDL_KeyboardEvent']]],
  ['right_5fcoeff_373',['right_coeff',['../_s_d_l__haptic_8h.html#aba08b5cf32eaa731813117458dca7710',1,'SDL_HapticCondition']]],
  ['right_5fsat_374',['right_sat',['../_s_d_l__haptic_8h.html#ac923a3cfe907fc31483f4103516bf280',1,'SDL_HapticCondition']]],
  ['rloss_375',['Rloss',['../_s_d_l__pixels_8h.html#af7e7eea7b82eee97ee172ea9c119f490',1,'SDL_PixelFormat']]],
  ['rmask_376',['Rmask',['../_s_d_l__pixels_8h.html#ad72f42bead0db7f2408ae57ea93aa168',1,'SDL_PixelFormat']]],
  ['rshift_377',['Rshift',['../_s_d_l__pixels_8h.html#a2d79297d36a08f7b9ea9bda330d9eb02',1,'SDL_PixelFormat']]],
  ['rw_5fseek_5fcur_378',['RW_SEEK_CUR',['../_s_d_l__rwops_8h.html#aba5f3b60c197def370ffa2ca1ab1348d',1,'SDL_rwops.h']]],
  ['rw_5fseek_5fend_379',['RW_SEEK_END',['../_s_d_l__rwops_8h.html#a6cf141faabd1b8f2ec3c03cf76eaf553',1,'SDL_rwops.h']]],
  ['rw_5fseek_5fset_380',['RW_SEEK_SET',['../_s_d_l__rwops_8h.html#ac028b032bb8230df64bc6284e04789f5',1,'SDL_rwops.h']]]
];
