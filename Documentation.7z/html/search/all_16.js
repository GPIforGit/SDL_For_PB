var searchData=
[
  ['value_2670',['value',['../_s_d_l__atomic_8h.html#ac4f474c82e82cbb89ca7c36dd52be0ed',1,'SDL_atomic_t::value()'],['../_s_d_l__events_8h.html#ae36d960bffe70dcf148258f6dbcb0ef8',1,'SDL_JoyAxisEvent::value()'],['../_s_d_l__events_8h.html#aa4f4dc93a5c52b0806c5844196244e51',1,'SDL_JoyHatEvent::value()'],['../_s_d_l__events_8h.html#ae36d960bffe70dcf148258f6dbcb0ef8',1,'SDL_ControllerAxisEvent::value()'],['../_s_d_l__gamecontroller_8h.html#afe00c6d05eb3db5629a1a14d58af4b3c',1,'SDL_GameControllerButtonBind::value()']]],
  ['version_2671',['version',['../_s_d_l__pixels_8h.html#a5d07ecb490ddbe3cdc17e84185b7aeb1',1,'SDL_Palette']]],
  ['void_2672',['void',['../_s_d_l__audio_8h.html#aa5cb90967788ada2711894ca158ece01',1,'SDL_audio.h']]],
  ['volume_2673',['volume',['../_s_d_l__mixer_8h.html#a96eebcd662128c3c25b12aed9eb75009',1,'Mix_Chunk']]]
];
