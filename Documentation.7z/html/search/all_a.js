var searchData=
[
  ['jaxis_168',['jaxis',['../_s_d_l__events_8h.html#a4b6be0bb6f456b320e33d344ae3da7c5',1,'SDL_Event']]],
  ['jball_169',['jball',['../_s_d_l__events_8h.html#a3a7002a9bea0e40a43f41df855bc9782',1,'SDL_Event']]],
  ['jbutton_170',['jbutton',['../_s_d_l__events_8h.html#ad723f7a3adf34248d74786401a257cd3',1,'SDL_Event']]],
  ['jdevice_171',['jdevice',['../_s_d_l__events_8h.html#a3cc807a742e4243fe2e46276ebac7290',1,'SDL_Event']]],
  ['jhat_172',['jhat',['../_s_d_l__events_8h.html#aea419b4a0b6aa542b5e3c8378b488dd7',1,'SDL_Event']]]
];
