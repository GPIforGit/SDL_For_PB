var searchData=
[
  ['offset_348',['offset',['../_s_d_l__haptic_8h.html#a7e9673499362bfbeafc5376833a641be',1,'SDL_HapticPeriodic::offset()'],['../struct_s_d_l___r_wops.html#a8188abdf32532b1714375ee8b94a3675',1,'SDL_RWops::offset()']]]
];
