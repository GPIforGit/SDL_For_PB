var searchData=
[
  ['_5fsdlnet_5fgenericsocket_2685',['_SDLNet_GenericSocket',['../_s_d_l__net_8h.html#struct___s_d_l_net___generic_socket',1,'']]]
];
