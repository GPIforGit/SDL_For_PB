var searchData=
[
  ['windowshapemode_4022',['WindowShapeMode',['../_s_d_l__shape_8h.html#aa30948f2699e316a43b740eccebe5c20',1,'SDL_shape.h']]]
];
