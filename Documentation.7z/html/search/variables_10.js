var searchData=
[
  ['quit_3858',['quit',['../_s_d_l__events_8h.html#a08f33cf663e5a5227cc5b681017af20c',1,'SDL_Event']]]
];
