var searchData=
[
  ['g_3787',['g',['../_s_d_l__messagebox_8h.html#ab4c6f97b95a6d0a8058a62eab9c78c43',1,'SDL_MessageBoxColor::g()'],['../_s_d_l__pixels_8h.html#ab4c6f97b95a6d0a8058a62eab9c78c43',1,'SDL_Color::g()']]],
  ['gestureid_3788',['gestureId',['../_s_d_l__events_8h.html#ad3686651e65f306de48618ca5c121241',1,'SDL_DollarGestureEvent']]],
  ['gloss_3789',['Gloss',['../_s_d_l__pixels_8h.html#ac44d76ceabdec273921c430afc4baf65',1,'SDL_PixelFormat']]],
  ['gmask_3790',['Gmask',['../_s_d_l__pixels_8h.html#acc0a1bbf72188b17065ddbae7de1a8a5',1,'SDL_PixelFormat']]],
  ['gshift_3791',['Gshift',['../_s_d_l__pixels_8h.html#a537451cb46162b729fbe10b9d2469712',1,'SDL_PixelFormat']]]
];
