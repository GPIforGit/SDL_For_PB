var searchData=
[
  ['magnitude_3819',['magnitude',['../_s_d_l__haptic_8h.html#a976c0cada4fae99d95d309257abdd71b',1,'SDL_HapticPeriodic']]],
  ['major_3820',['major',['../_s_d_l__version_8h.html#a302f1b7284c3bcdfa0dee1aa267b955e',1,'SDL_version']]],
  ['map_3821',['map',['../_s_d_l__surface_8h.html#a6305e21db64c3e35a648981e733414b3',1,'SDL_Surface']]],
  ['max_5ftexture_5fheight_3822',['max_texture_height',['../_s_d_l__render_8h.html#a0660205b899cefb8b2c807dc244296f7',1,'SDL_RendererInfo']]],
  ['max_5ftexture_5fwidth_3823',['max_texture_width',['../_s_d_l__render_8h.html#abe1e7efe1a1dae989c33c89e0597493d',1,'SDL_RendererInfo']]],
  ['maxlen_3824',['maxlen',['../_s_d_l__net_8h.html#a245b5bee0d02a20222d815dbeaaac0fb',1,'UDPpacket']]],
  ['maxnum_3825',['maxnum',['../struct_s_d_l___r_wops.html#af42f7e72c90f27a8b6622f9f89f6e589',1,'SDL_RWops']]],
  ['message_3826',['message',['../_s_d_l__messagebox_8h.html#a254bf0858da09c96a48daf64404eb4f8',1,'SDL_MessageBoxData']]],
  ['mgesture_3827',['mgesture',['../_s_d_l__events_8h.html#aa0605c4f966521b135a1a429a2a255f4',1,'SDL_Event']]],
  ['minor_3828',['minor',['../_s_d_l__version_8h.html#a8eb06ff08bc41ff4eed7c42fc8b40d50',1,'SDL_version']]],
  ['mod_3829',['mod',['../_s_d_l__keyboard_8h.html#a09294cbc86473d2bcb27513748b81aec',1,'SDL_Keysym']]],
  ['mode_3830',['mode',['../_s_d_l__shape_8h.html#ab4a7dfd410934bebf80e105f6fa72b74',1,'SDL_WindowShapeMode']]],
  ['motion_3831',['motion',['../_s_d_l__events_8h.html#a8b74ec063362bbd2e4ec6d1a878eb0ca',1,'SDL_Event']]],
  ['msg_3832',['msg',['../_s_d_l__events_8h.html#a7b74458e040fff2d0b02a00df56049b0',1,'SDL_SysWMEvent']]]
];
