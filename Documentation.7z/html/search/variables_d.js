var searchData=
[
  ['name_3833',['name',['../_s_d_l__render_8h.html#a8f8f80d37794cde9472343e4487ba3eb',1,'SDL_RendererInfo']]],
  ['ncolors_3834',['ncolors',['../_s_d_l__pixels_8h.html#aeac67cf686cea9cb1d69661714767244',1,'SDL_Palette']]],
  ['needed_3835',['needed',['../_s_d_l__audio_8h.html#abaf982c31b3b8169de1fa31a5d139042',1,'SDL_AudioCVT']]],
  ['next_3836',['next',['../_s_d_l__assert_8h.html#acbb7ff1c6f9666cdb6dbd637662f153b',1,'SDL_AssertData::next()'],['../_s_d_l__pixels_8h.html#ac7e2744f93a892694f8d360c341c2a3f',1,'SDL_PixelFormat::next()']]],
  ['num_3837',['num',['../struct_s_d_l___r_wops.html#ae3010566a844e562017f4cc824752d8f',1,'SDL_RWops']]],
  ['num_5ftexture_5fformats_3838',['num_texture_formats',['../_s_d_l__render_8h.html#a0cfcc641f2a99b9f5a0e3e3eb5fbbefe',1,'SDL_RendererInfo']]],
  ['numbuttons_3839',['numbuttons',['../_s_d_l__messagebox_8h.html#adff7d306bb56e132b0060191672c9525',1,'SDL_MessageBoxData']]],
  ['numfingers_3840',['numFingers',['../_s_d_l__events_8h.html#a243e821a31b9c308c8c119999c750bcb',1,'SDL_MultiGestureEvent::numFingers()'],['../_s_d_l__events_8h.html#a55993ff0c72b4edca92780d6016b88af',1,'SDL_DollarGestureEvent::numFingers()']]]
];
