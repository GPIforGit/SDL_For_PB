var struct_s_d_l___r_wops =
[
    [ "int", "struct_s_d_l___r_wops.html#a1eaac7a271585ada805ca27aaf39e3cd", null ],
    [ "Sint64", "struct_s_d_l___r_wops.html#a4767ff7a728cc975b036871b8f6423c6", null ],
    [ "Sint64", "struct_s_d_l___r_wops.html#a87c98da2393dc7d5b085ef88da2a2d48", null ],
    [ "size_t", "struct_s_d_l___r_wops.html#aa7ef15421aa6f0b205322fcf0daa52d1", null ],
    [ "size_t", "struct_s_d_l___r_wops.html#a2ec61617a2df2c3c1848071e52fdbe43", null ],
    [ "hidden", "struct_s_d_l___r_wops.html#a497d1a7a610844edcdf1d6e77460b8bd", null ],
    [ "maxnum", "struct_s_d_l___r_wops.html#af42f7e72c90f27a8b6622f9f89f6e589", null ],
    [ "num", "struct_s_d_l___r_wops.html#ae3010566a844e562017f4cc824752d8f", null ],
    [ "offset", "struct_s_d_l___r_wops.html#a8188abdf32532b1714375ee8b94a3675", null ],
    [ "ptr", "struct_s_d_l___r_wops.html#add9af9569af79ec26dd741fb226b38ba", null ],
    [ "ptr", "struct_s_d_l___r_wops.html#ab6679b8a3625461c4f6c523048234022", null ],
    [ "size", "struct_s_d_l___r_wops.html#ae1f6914bd1202350b5825827bef9bba5", null ],
    [ "size", "struct_s_d_l___r_wops.html#a96cd5f3798d2e644ce8ebb38303619fb", null ],
    [ "type", "struct_s_d_l___r_wops.html#aa40a9b05c3154032b9f2d7220e9f08dc", null ],
    [ "whence", "struct_s_d_l___r_wops.html#a7ad96cded7d3af15ca51dc74e49fb1c2", null ]
];